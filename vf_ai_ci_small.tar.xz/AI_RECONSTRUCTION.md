# VideoFlow Professional Core 1.0.0 — AI Reconstruction

## Status

**IMPLEMENTED IN SOURCE / BETA UNTIL RUNTIME CERTIFICATION**

VideoFlow now contains a genuine local neural-inpainting pipeline. It does not rename Blur, Pixelate, Cover, Clone, spatial averaging or FFmpeg filters as AI. The AI controls remain unavailable until a checksum-valid model and ONNX Runtime pack are locally installed and an actual inference session can initialize.

Use watermark reconstruction only on media you own or are authorized to modify.

## Runtime and model design

- Runtime: ONNX Runtime Web.
- Primary provider: WebGPU after real adapter/device initialization.
- Fallback provider: WebAssembly.
- Model family: LaMa 512 ONNX model pack staged by `scripts/stage-ai-pack-ci.sh`.
- Model integrity: expected SHA-256 is pinned in the model registry/staging flow and checked before execution.
- Model input contract: a single `[1,4,512,512]` tensor containing masked RGB plus the mask channel.
- Model/runtime assets are local and base-path safe; no frame or mask is sent to a cloud inference API.

The core package keeps large AI binaries outside normal PWA precaching. Model installation stores validated assets in a dedicated local AI cache so the core PWA does not unexpectedly download a large model.

## Implemented AI pipeline

- checksum-validated local model installation/removal;
- WebGPU capability initialization with WASM fallback;
- worker-based session reuse and inference isolation;
- ROI extraction and bounded 512×512 neural inference;
- mask expansion, dilation/padding and feathering;
- rectangle and ellipse masks;
- 4K source-resolution composition without full-frame neural inference;
- Fast, Balanced, High and Maximum quality modes that change actual processing parameters;
- directional Track Forward / Track Backward template tracking;
- measured tracking confidence and low-confidence warnings;
- editable/persisted tracking corrections;
- bounded temporal-frame history;
- block-motion-assisted temporal alignment;
- temporal stabilization/consistency blending;
- edge-aware mask composition and local color/luminance matching;
- cancellable AI jobs with worker termination/resource cleanup;
- original-audio preservation during AI video export;
- bounded/segmented AI rendering compatible with large-media workflows;
- proxy-to-source coordinate mapping for original-resolution reconstruction;
- AI settings, diagnostics and local self-test hooks;
- offline model cache architecture and explicit model removal.

## 4K and large media

The AI path is ROI-first. For a 3840×2160 frame, only a padded watermark region is normalized for the 512×512 model, then the reconstructed ROI is blended back into the original-resolution frame. Long and multi-gigabyte media use the existing reference/proxy/relink architecture and bounded rendering; the full source is not loaded into AI memory.

## Limitations / certification boundary

Actual LaMa inference with the packaged model, offline model reload, Chromium/Firefox/WebKit AI execution and browser-produced 3840×2160 AI output require a fresh dependency-backed production build and browser runtime. Those runtime gates are **NOT VERIFIED** in this execution environment because package-registry access is unavailable and the installed Chromium is enterprise-blocked from navigating to localhost/file/data URLs.

Until those runtime gates pass, AI status is **BETA**, not release-certified PASS.
