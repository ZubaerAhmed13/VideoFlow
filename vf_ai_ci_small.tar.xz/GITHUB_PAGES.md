# VideoFlow Professional Core 1.0.0 — GitHub Pages Deployment

## Included deployment workflow

`.github/workflows/deploy-pages.yml` uses official GitHub Pages actions. It performs dependency installation, portable tests, TypeScript validation, lint, production build, static-output verification and a Chromium critical E2E gate before uploading the generated static artifact.

A separate `.github/workflows/release-verification.yml` runs the full Chromium + Firefox + WebKit Playwright release matrix.

## Nested repository paths

The app is designed for URLs such as:

```text
https://USERNAME.github.io/REPOSITORY/
```

Runtime paths use the deployment base rather than hard-coding a username or repository. Manifest start/scope are `./`; service-worker shell URLs are built from `self.registration.scope`; FFmpeg JavaScript/WASM are local, base-relative assets.

The static verifier rejects root-relative application, service-worker, manifest and FFmpeg URLs that would break a repository subpath.

## FFmpeg/WASM

VideoFlow ships the single-thread compatible local FFmpeg core as ordinary static files:

```text
vendor/ffmpeg/ffmpeg-core.js
vendor/ffmpeg/ffmpeg-core.wasm
```

The release no longer requires `.wasm.gz` plus browser-side `DecompressionStream` just to initialize FFmpeg. Core functionality does not require `SharedArrayBuffer` or cross-origin isolation, which makes normal GitHub Pages hosting viable.

## PWA

`pwa7` caches only application-shell/local-runtime resources. Imported user media and generated proxies are not added to the service-worker cache. When an update is waiting, VideoFlow saves the active project and clears recovery state before asking the service worker to activate, preventing a routine PWA update from discarding unsaved project state.

## Static package

The packaged release includes a verified `dist/` directory. `npm run verify:dist` checks its required shell/FFmpeg assets and nested-path safety.

Because the current execution environment cannot restore npm packages or navigate a browser, the supplied static build can be statically verified here but a new local production rebuild/runtime deployment is recorded as NOT VERIFIED in `RELEASE_CERTIFICATION.md`. Normal GitHub Actions has the complete rebuild/runtime gates configured.
