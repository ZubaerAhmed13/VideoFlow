# VideoFlow Professional Core 1.0.0 — Browser Support

Status date: 2026-08-30

“Implemented” describes code/static capability. “NOT VERIFIED” means the actual browser gate could not execute in this environment and is not converted into a pass.

| Capability | Chromium | Firefox | Safari/WebKit |
| --- | --- | --- | --- |
| App shell / nested base | NOT VERIFIED runtime | NOT VERIFIED | NOT VERIFIED |
| IndexedDB projects/recovery/proxies | Implemented; NOT VERIFIED runtime | Implemented; NOT VERIFIED | Implemented; NOT VERIFIED |
| File System Access persistent source references | Supported path where API exists; NOT VERIFIED runtime | Fallback relink/session path | Fallback relink/session path |
| Direct-to-disk segmented MP4 | Implemented where `showSaveFilePicker`/`createWritable` exist | Standard-download fallback | Standard-download fallback / platform-dependent |
| Proxy editing | Implemented | Implemented | Implemented |
| Deterministic FFmpeg WASM export | Implemented; NOT VERIFIED runtime | Implemented; NOT VERIFIED | Implemented; NOT VERIFIED |
| 4K browser export | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |
| Screen recording | Permission/API dependent | Permission/API dependent | Version/permission dependent |
| Camera / microphone recording | Permission dependent | Permission dependent | Permission dependent |
| Service worker/PWA shell | Static checks PASS; runtime NOT VERIFIED | Static checks PASS; runtime NOT VERIFIED | Platform dependent; runtime NOT VERIFIED |
| Offline reload | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |
| Command palette/keyboard | Implemented; E2E configured | Implemented; E2E configured | Implemented; E2E configured |
| Responsive 1440/768/390 layouts | E2E configured | E2E configured | E2E configured |

## Current environment boundary

Chromium 144.0.7559.96 is installed, but the container applies an enterprise `URLBlocklist: ["*"]`; localhost, `file:` and `data:` navigation is blocked with `net::ERR_BLOCKED_BY_ADMINISTRATOR`. Python Playwright is installed, but its Firefox and WebKit executables are not installed locally and this environment cannot download them. Therefore no engine is falsely marked passed.

## CI verification

`.github/workflows/release-verification.yml` restores the locked dependencies, installs Chromium/Firefox/WebKit, builds the production output and runs the actual Playwright suite. The suite includes nested-path load, project/import/timeline flows, track controls, quick actions, crop/watermark interaction, deterministic export, real 4K export in Chromium, responsive layouts, command palette and offline-shell coverage.
