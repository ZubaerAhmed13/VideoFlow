# VideoFlow Professional Core 1.0.0 — AI Reconstruction

## Release status

**NOT INSTALLED / OPTIONAL**

VideoFlow 1.0.0 does not ship a neural inpainting model and does not label blur, pixelate, cover or clone as AI. This is intentional and compliant with the release specification's no-fake rule.

The Watermark Studio includes real local non-neural tools:

- Blur
- Pixelate
- Cover
- Nearby-region Clone
- timed masks
- editable linear mask keyframes
- before / processed / split preview

Use these features only on media you own or are authorized to modify.

## Reserved local-AI architecture

The core has resource-management and mask/keyframe architecture suitable for an optional future model pack. A genuine AI pack must satisfy all of the following before the UI may show it as installed:

1. inference runs locally with no media upload or hidden cloud API;
2. ONNX Runtime Web or an equivalent local runtime is packaged/loaded explicitly;
3. WebGPU may accelerate inference, with a real WebAssembly fallback where supported;
4. 4K frames are processed region-of-interest first rather than feeding full 3840×2160 frames unnecessarily;
5. temporal neighboring frames are used for video reconstruction rather than independent per-frame image inpainting only;
6. motion estimation/tracking is genuine and editable; simple translation must not be called optical flow;
7. reconstructed patches use feather/edge/color consistency to avoid visible rectangular seams;
8. inference work is cancellable and serialized through the resource manager;
9. installed models remain locally usable offline;
10. UI explains that reconstruction creates plausible replacement content, not recovered original pixels.

## Model / size / performance

No model is bundled in this release, therefore:

- model name: none
- model size: 0 bundled bytes
- WebGPU acceleration: not installed
- WASM inference fallback: not installed
- temporal window: not installed
- automatic tracking confidence: not installed
- estimated performance: not claimed

VideoFlow does not fabricate GPU memory, expected fps, quality scores or reconstruction capability.

## Privacy

Core media processing remains local. No AI model, inference endpoint, analytics system or media upload is required by VideoFlow 1.0.0.
