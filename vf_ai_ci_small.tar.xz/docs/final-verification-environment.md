# Final Verification Environment Boundary

Date: 2026-08-30

This file records external restrictions encountered during the final VideoFlow 1.0.0 certification pass. They are not converted into application PASS results.

## npm / fresh production build

The package registry cannot be resolved from this execution container. A fresh locked install fails with `EAI_AGAIN` for `registry.npmjs.org`; offline installation also stops when an uncached locked tarball is required. The supplied/repaired static `dist/` therefore remains the distributable that is statically verified in this package, while the GitHub workflows are configured to perform a clean rebuild on a normal runner.

## Chromium

System Chromium 144.0.7559.96 exists, but `/etc/chromium/policies/managed/000_policy_merge.json` contains an enterprise `URLBlocklist` of `[*]`. Browser navigation to localhost, file and data URLs returns `net::ERR_BLOCKED_BY_ADMINISTRATOR`. This system policy was not bypassed or modified.

## Firefox / WebKit

Python Playwright 1.57.0 is installed, but its referenced Firefox and WebKit browser executables are absent. Browser downloads cannot be completed in the current network-restricted container.

## What was genuinely executed

- Portable Node regression suite: 43 passed, 0 failed, 3 dependency-only skips.
- Security source audit: PASS, 88 source files, CSP present.
- Deterministic native FFmpeg render-plan verification: PASS.
- Static/nested-path distribution verifier: PASS, 23 files.
- Real 3840x2160 source and native effects/range outputs verified with ffprobe.
- Real sparse 3 GiB, 3840x2160 source semantics verified with ffprobe and original-quality native range extraction.

The browser-produced 4K and three-browser runtime gates remain `NOT VERIFIED` solely because those executions cannot be performed inside this controlled environment.
