import { videoFlowResources } from "../resource-manager";
import { runImageInpainting } from "./AIInferenceEngine";
import { buildModelMask } from "./inpainting/MaskProcessor";
import { extractROI, normalizedMaskToROI } from "./inpainting/ROIPreprocessor";
import { blendMotionCompensatedHistory, type TemporalFrame } from "./temporal/TemporalContext";
import type { AIFrameResult, AISettings } from "./types";

export const DEFAULT_AI_SETTINGS: AISettings = { provider: "auto", quality: "balanced", roiPadding: 96, maskExpansion: 8, feather: 12, temporalWindow: 9, consistencyStrength: 0.18, blendingStrength: 0.85, trackingMethod: "auto" };

export function effectiveAISettings(settings: AISettings): AISettings {
  const presets = {
    fast: { roiPadding: Math.min(settings.roiPadding, 72), maskExpansion: Math.min(settings.maskExpansion, 6), temporalWindow: 3, consistencyStrength: Math.min(settings.consistencyStrength, 0.1), blendingStrength: Math.min(settings.blendingStrength, 0.82) },
    balanced: {},
    high: { roiPadding: Math.max(settings.roiPadding, 128), maskExpansion: Math.max(settings.maskExpansion, 10), temporalWindow: Math.max(settings.temporalWindow, 11), consistencyStrength: Math.max(settings.consistencyStrength, 0.24), blendingStrength: Math.max(settings.blendingStrength, 0.88) },
    maximum: { roiPadding: Math.max(settings.roiPadding, 160), maskExpansion: Math.max(settings.maskExpansion, 12), temporalWindow: Math.max(settings.temporalWindow, 15), consistencyStrength: Math.max(settings.consistencyStrength, 0.32), blendingStrength: Math.max(settings.blendingStrength, 0.92) },
  } as const;
  return { ...settings, ...presets[settings.quality] };
}

export async function reconstructFrame(
  source: CanvasImageSource,
  sourceWidth: number,
  sourceHeight: number,
  mask: { x: number; y: number; width: number; height: number; shape: "rectangle" | "ellipse" },
  settings: AISettings = DEFAULT_AI_SETTINGS,
  previous?: TemporalFrame[] | null,
  signal?: AbortSignal,
): Promise<AIFrameResult> {
  const effective = effectiveAISettings(settings);
  if (signal?.aborted) throw new DOMException("AI reconstruction cancelled.", "AbortError");
  return videoFlowResources.run("ai", async () => {
    const roi = normalizedMaskToROI(mask, sourceWidth, sourceHeight, effective.roiPadding);
    const image = extractROI(source, roi, 512);
    const modelMask = buildModelMask(mask, roi, 512, effective.maskExpansion);
    if (signal?.aborted) throw new DOMException("AI reconstruction cancelled.", "AbortError");
    const result = await runImageInpainting(image, modelMask, effective, signal);
    if (signal?.aborted) throw new DOMException("AI reconstruction cancelled.", "AbortError");
    const history = previous ?? [];
    const temporal = blendMotionCompensatedHistory(result.imageData, image, history, effective.consistencyStrength);
    return { imageData: temporal.imageData, sourceROI: image, provider: result.provider, inferenceMs: result.inferenceMs, roi, temporalConfidence: temporal.confidence };
  });
}
