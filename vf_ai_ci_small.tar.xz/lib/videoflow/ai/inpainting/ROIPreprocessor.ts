import type { ROI } from "../types";

export function normalizedMaskToROI(mask: { x: number; y: number; width: number; height: number }, sourceWidth: number, sourceHeight: number, padding = 96): ROI {
  const x0 = Math.max(0, Math.floor(mask.x * sourceWidth) - padding);
  const y0 = Math.max(0, Math.floor(mask.y * sourceHeight) - padding);
  const x1 = Math.min(sourceWidth, Math.ceil((mask.x + mask.width) * sourceWidth) + padding);
  const y1 = Math.min(sourceHeight, Math.ceil((mask.y + mask.height) * sourceHeight) + padding);
  return { x: x0, y: y0, width: Math.max(1, x1 - x0), height: Math.max(1, y1 - y0), sourceWidth, sourceHeight };
}

export function extractROI(source: CanvasImageSource, roi: ROI, size = 512): ImageData {
  const canvas = new OffscreenCanvas(size, size);
  const context = canvas.getContext("2d", { willReadFrequently: true });
  if (!context) throw new Error("AI ROI canvas is unavailable.");
  context.drawImage(source, roi.x, roi.y, roi.width, roi.height, 0, 0, size, size);
  return context.getImageData(0, 0, size, size);
}
