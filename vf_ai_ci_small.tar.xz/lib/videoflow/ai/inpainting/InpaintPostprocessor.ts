import type { ROI } from "../types";

type MaskGeometry = { x: number; y: number; width: number; height: number; shape: "rectangle" | "ellipse" };

export function compositeInpaintedROI(
  target: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
  patch: ImageData,
  roi: ROI,
  mask: MaskGeometry,
  feather = 12,
  opacity = 1,
): void {
  const width = Math.max(1, Math.round(roi.width));
  const height = Math.max(1, Math.round(roi.height));
  const layer = new OffscreenCanvas(width, height);
  const layerContext = layer.getContext("2d")!;
  const patchCanvas = new OffscreenCanvas(patch.width, patch.height);
  patchCanvas.getContext("2d")!.putImageData(patch, 0, 0);
  layerContext.drawImage(patchCanvas, 0, 0, patch.width, patch.height, 0, 0, width, height);

  const maskCanvas = new OffscreenCanvas(width, height);
  const maskContext = maskCanvas.getContext("2d")!;
  const mx = mask.x * roi.sourceWidth - roi.x;
  const my = mask.y * roi.sourceHeight - roi.y;
  const mw = mask.width * roi.sourceWidth;
  const mh = mask.height * roi.sourceHeight;
  const blur = Math.max(0, Math.min(48, feather));
  maskContext.save();
  maskContext.filter = blur ? `blur(${blur}px)` : "none";
  maskContext.fillStyle = "white";
  if (mask.shape === "ellipse") {
    maskContext.beginPath();
    maskContext.ellipse(mx + mw / 2, my + mh / 2, Math.max(1, mw / 2), Math.max(1, mh / 2), 0, 0, Math.PI * 2);
    maskContext.fill();
  } else {
    maskContext.fillRect(mx, my, mw, mh);
  }
  maskContext.restore();

  layerContext.globalCompositeOperation = "destination-in";
  layerContext.drawImage(maskCanvas, 0, 0);
  layerContext.globalCompositeOperation = "source-over";
  target.save();
  target.globalAlpha = Math.max(0, Math.min(1, opacity));
  target.drawImage(layer, roi.x, roi.y, roi.width, roi.height);
  target.restore();
}
