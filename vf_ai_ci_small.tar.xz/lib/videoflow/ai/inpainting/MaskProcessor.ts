import type { ROI } from "../types";

export function buildModelMask(mask: { x: number; y: number; width: number; height: number; shape: "rectangle" | "ellipse" }, roi: ROI, size = 512, expansion = 8): Float32Array {
  const output = new Float32Array(size * size);
  const sx = size / roi.width;
  const sy = size / roi.height;
  const x0 = Math.max(0, (mask.x * roi.sourceWidth - roi.x) * sx - expansion);
  const y0 = Math.max(0, (mask.y * roi.sourceHeight - roi.y) * sy - expansion);
  const x1 = Math.min(size, ((mask.x + mask.width) * roi.sourceWidth - roi.x) * sx + expansion);
  const y1 = Math.min(size, ((mask.y + mask.height) * roi.sourceHeight - roi.y) * sy + expansion);
  const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, rx = Math.max(1, (x1 - x0) / 2), ry = Math.max(1, (y1 - y0) / 2);
  for (let y = Math.floor(y0); y < Math.ceil(y1); y += 1) for (let x = Math.floor(x0); x < Math.ceil(x1); x += 1) {
    const inside = mask.shape === "ellipse" ? ((x - cx) ** 2) / (rx ** 2) + ((y - cy) ** 2) / (ry ** 2) <= 1 : true;
    if (inside && x >= 0 && y >= 0 && x < size && y < size) output[y * size + x] = 1;
  }
  return output;
}
