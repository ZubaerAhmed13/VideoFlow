import { estimateTranslation, translateImage, type MotionVector } from "./MotionEstimator";

export interface TemporalFrame {
  source: ImageData;
  reconstruction: ImageData;
}

export class TemporalContext {
  private readonly frames: TemporalFrame[] = [];
  constructor(private windowSize: number) {}

  push(source: ImageData, reconstruction: ImageData): void {
    this.frames.push({ source, reconstruction });
    const keep = Math.max(1, Math.floor(this.windowSize / 2));
    while (this.frames.length > keep) this.frames.shift();
  }

  history(): TemporalFrame[] {
    return [...this.frames];
  }

  clear(): void {
    this.frames.length = 0;
  }
}

export interface TemporalBlendResult {
  imageData: ImageData;
  motion: MotionVector[];
  confidence: number;
}

export function blendMotionCompensatedHistory(
  current: ImageData,
  currentSource: ImageData,
  history: TemporalFrame[],
  strength: number,
): TemporalBlendResult {
  const compatible = history.filter(
    (frame) =>
      frame.source.width === current.width &&
      frame.source.height === current.height &&
      frame.reconstruction.width === current.width &&
      frame.reconstruction.height === current.height,
  );
  if (!compatible.length || strength <= 0) {
    return { imageData: current, motion: [], confidence: compatible.length ? 1 : 0 };
  }

  const alpha = Math.max(0, Math.min(0.65, strength));
  const motion: MotionVector[] = [];
  const aligned = compatible.map((frame, index) => {
    const vector = estimateTranslation(frame.source, currentSource, 24);
    motion.push(vector);
    const recency = (index + 1) / compatible.length;
    return {
      image: translateImage(frame.reconstruction, vector.dx, vector.dy),
      weight: Math.max(0.02, recency * Math.max(0.08, vector.confidence)),
    };
  });

  const out = new ImageData(current.width, current.height);
  for (let i = 0; i < current.data.length; i += 4) {
    let weightSum = 0;
    let r = 0;
    let g = 0;
    let b = 0;
    for (const frame of aligned) {
      if (frame.image.data[i + 3] === 0) continue;
      weightSum += frame.weight;
      r += frame.image.data[i] * frame.weight;
      g += frame.image.data[i + 1] * frame.weight;
      b += frame.image.data[i + 2] * frame.weight;
    }
    if (weightSum) {
      out.data[i] = current.data[i] * (1 - alpha) + (r / weightSum) * alpha;
      out.data[i + 1] = current.data[i + 1] * (1 - alpha) + (g / weightSum) * alpha;
      out.data[i + 2] = current.data[i + 2] * (1 - alpha) + (b / weightSum) * alpha;
    } else {
      out.data[i] = current.data[i];
      out.data[i + 1] = current.data[i + 1];
      out.data[i + 2] = current.data[i + 2];
    }
    out.data[i + 3] = 255;
  }
  const confidence = motion.reduce((sum, vector) => sum + vector.confidence, 0) / Math.max(1, motion.length);
  return { imageData: out, motion, confidence };
}
