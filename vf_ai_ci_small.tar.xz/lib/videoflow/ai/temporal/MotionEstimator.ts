export interface MotionVector {
  dx: number;
  dy: number;
  confidence: number;
  normalizedError: number;
}

function luminance(data: Uint8ClampedArray, index: number): number {
  return data[index] * 0.2126 + data[index + 1] * 0.7152 + data[index + 2] * 0.0722;
}

function translationError(
  previous: ImageData,
  current: ImageData,
  dx: number,
  dy: number,
  stride: number,
): { error: number; samples: number } {
  const width = current.width;
  const height = current.height;
  const margin = Math.max(Math.abs(dx), Math.abs(dy), 4);
  let error = 0;
  let samples = 0;
  for (let y = margin; y < height - margin; y += stride) {
    const py = y - dy;
    if (py < 0 || py >= height) continue;
    for (let x = margin; x < width - margin; x += stride) {
      const px = x - dx;
      if (px < 0 || px >= width) continue;
      const ci = (y * width + x) * 4;
      const pi = (py * width + px) * 4;
      error += Math.abs(luminance(current.data, ci) - luminance(previous.data, pi));
      samples += 1;
    }
  }
  return { error: samples ? error / samples : Number.POSITIVE_INFINITY, samples };
}

/**
 * Estimate global ROI translation between adjacent source frames using
 * coarse-to-fine luminance block matching. This is intentionally named
 * translation estimation rather than optical flow: it measures real motion,
 * but does not claim a dense per-pixel flow field.
 */
export function estimateTranslation(
  previous: ImageData,
  current: ImageData,
  maxShift = 24,
): MotionVector {
  if (previous.width !== current.width || previous.height !== current.height) {
    return { dx: 0, dy: 0, confidence: 0, normalizedError: 1 };
  }
  const candidates: Array<{ dx: number; dy: number; error: number }> = [];
  let best = { dx: 0, dy: 0, error: Number.POSITIVE_INFINITY };
  const coarseStep = Math.max(2, Math.round(maxShift / 6));
  for (let dy = -maxShift; dy <= maxShift; dy += coarseStep) {
    for (let dx = -maxShift; dx <= maxShift; dx += coarseStep) {
      const result = translationError(previous, current, dx, dy, 8);
      const candidate = { dx, dy, error: result.error };
      candidates.push(candidate);
      if (candidate.error < best.error) best = candidate;
    }
  }
  const refineRadius = coarseStep;
  for (let dy = best.dy - refineRadius; dy <= best.dy + refineRadius; dy += 1) {
    if (Math.abs(dy) > maxShift) continue;
    for (let dx = best.dx - refineRadius; dx <= best.dx + refineRadius; dx += 1) {
      if (Math.abs(dx) > maxShift) continue;
      const result = translationError(previous, current, dx, dy, 5);
      const candidate = { dx, dy, error: result.error };
      candidates.push(candidate);
      if (candidate.error < best.error) best = candidate;
    }
  }
  const sorted = candidates.sort((a, b) => a.error - b.error);
  const second = sorted.find((candidate) => candidate.dx !== best.dx || candidate.dy !== best.dy);
  const normalizedError = Math.max(0, Math.min(1, best.error / 64));
  const separation = second && Number.isFinite(second.error)
    ? Math.max(0, Math.min(1, (second.error - best.error) / Math.max(1, second.error)))
    : 0;
  const confidence = Math.max(0, Math.min(1, (1 - normalizedError) * 0.7 + separation * 0.3));
  return { dx: best.dx, dy: best.dy, confidence, normalizedError };
}

export function translateImage(image: ImageData, dx: number, dy: number): ImageData {
  const out = new ImageData(image.width, image.height);
  const width = image.width;
  const height = image.height;
  for (let y = 0; y < height; y += 1) {
    const sy = y - dy;
    if (sy < 0 || sy >= height) continue;
    for (let x = 0; x < width; x += 1) {
      const sx = x - dx;
      if (sx < 0 || sx >= width) continue;
      const source = (sy * width + sx) * 4;
      const target = (y * width + x) * 4;
      out.data[target] = image.data[source];
      out.data[target + 1] = image.data[source + 1];
      out.data[target + 2] = image.data[source + 2];
      out.data[target + 3] = image.data[source + 3] || 255;
    }
  }
  return out;
}
