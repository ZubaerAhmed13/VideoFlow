import type { TrackingPoint } from "../types";

function patchError(a: ImageData, b: ImageData): number {
  let error = 0;
  const stride = Math.max(4, Math.floor(a.data.length / 4096 / 4));
  for (let i = 0; i < a.data.length; i += 4 * stride) error += Math.abs(a.data[i] - b.data[i]) + Math.abs(a.data[i + 1] - b.data[i + 1]) + Math.abs(a.data[i + 2] - b.data[i + 2]);
  return error;
}

export async function trackTemplate(frames: Array<{ time: number; image: ImageBitmap }>, initial: TrackingPoint, searchRadius = 24): Promise<TrackingPoint[]> {
  if (!frames.length) return [];
  const width = frames[0].image.width, height = frames[0].image.height;
  const crop = new OffscreenCanvas(Math.max(8, Math.round(initial.width * width)), Math.max(8, Math.round(initial.height * height)));
  const cropContext = crop.getContext("2d", { willReadFrequently: true })!;
  cropContext.drawImage(frames[0].image, initial.x * width, initial.y * height, initial.width * width, initial.height * height, 0, 0, crop.width, crop.height);
  const template = cropContext.getImageData(0, 0, crop.width, crop.height);
  const points = [initial];
  let last = initial;
  for (const frame of frames.slice(1)) {
    const ctxCanvas = new OffscreenCanvas(width, height); const ctx = ctxCanvas.getContext("2d", { willReadFrequently: true })!; ctx.drawImage(frame.image, 0, 0);
    let best = { error: Number.POSITIVE_INFINITY, x: last.x, y: last.y };
    const px = last.x * width, py = last.y * height;
    for (let dy = -searchRadius; dy <= searchRadius; dy += 4) for (let dx = -searchRadius; dx <= searchRadius; dx += 4) {
      const x = Math.max(0, Math.min(width - crop.width, px + dx)); const y = Math.max(0, Math.min(height - crop.height, py + dy));
      const candidate = ctx.getImageData(Math.round(x), Math.round(y), crop.width, crop.height); const error = patchError(template, candidate);
      if (error < best.error) best = { error, x: x / width, y: y / height };
    }
    const confidence = Math.max(0, Math.min(1, 1 - best.error / (template.data.length * 255 * 0.35)));
    last = { time: frame.time, x: best.x, y: best.y, width: initial.width, height: initial.height, confidence, method: "template" };
    points.push(last);
  }
  return points;
}
