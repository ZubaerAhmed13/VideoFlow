import { deploymentAssetUrl } from "../base-url";
import { detectAICapability } from "./AICapability";
import { getAIModelBytes } from "./AIModelLoader";
import { DEFAULT_AI_MODEL } from "./AIModelRegistry";
import type { AIProvider, AISettings } from "./types";

type Reply = { id: number; ok: boolean; error?: string; provider?: AIProvider; inferenceMs?: number; rgba?: ArrayBuffer };
let worker: Worker | null = null;
let initPromise: Promise<AIProvider> | null = null;
let sequence = 0;
const pending = new Map<number, { resolve: (value: Reply) => void; reject: (reason: unknown) => void }>();

function ensureWorker(): Worker {
  if (worker) return worker;
  worker = new Worker(new URL("../../../workers/ai-inference.worker.ts", import.meta.url), { type: "module", name: "videoflow-ai-inference" });
  worker.onmessage = (event: MessageEvent<Reply>) => {
    const request = pending.get(event.data.id);
    if (!request) return;
    pending.delete(event.data.id);
    event.data.ok ? request.resolve(event.data) : request.reject(new Error(event.data.error || "AI worker failed."));
  };
  worker.onerror = (event) => {
    const error = new Error(event.message || "AI inference worker crashed.");
    for (const request of pending.values()) request.reject(error);
    pending.clear();
    worker?.terminate();
    worker = null;
    initPromise = null;
  };
  return worker;
}

function request(type: string, payload: Record<string, unknown>, transfer: Transferable[] = []): Promise<Reply> {
  const active = ensureWorker();
  const id = ++sequence;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject });
    active.postMessage({ id, type, ...payload }, transfer);
  });
}

async function initialize(settings: AISettings): Promise<AIProvider> {
  if (!initPromise) initPromise = (async () => {
    const [model, capability] = await Promise.all([getAIModelBytes(DEFAULT_AI_MODEL), detectAICapability()]);
    if (!model) throw new Error("AI Reconstruction model not installed.");
    const requested = settings.provider === "auto" ? capability.recommendedProvider : settings.provider;
    const providers = requested === "webgpu" && capability.webgpu === "available" ? ["webgpu", "wasm"] : ["wasm"];
    const reply = await request("init", {
      runtimeUrl: deploymentAssetUrl("vendor/onnx/ort.webgpu.bundle.min.mjs"),
      model,
      providers,
      hardwareConcurrency: navigator.hardwareConcurrency || 2,
      imageInput: DEFAULT_AI_MODEL.imageInput,
      maskInput: DEFAULT_AI_MODEL.maskInput,
      outputName: DEFAULT_AI_MODEL.output,
      size: DEFAULT_AI_MODEL.inputWidth,
    }, [model]);
    return reply.provider ?? "wasm";
  })();
  return initPromise;
}

export async function runWorkerInpainting(image: ImageData, mask: Float32Array, settings: AISettings, signal?: AbortSignal): Promise<{ imageData: ImageData; provider: AIProvider; inferenceMs: number }> {
  if (signal?.aborted) throw new DOMException("AI reconstruction cancelled.", "AbortError");
  const provider = await initialize(settings);
  const rgba = new Uint8ClampedArray(image.data);
  const maskCopy = new Float32Array(mask);
  const abort = () => { void resetAIWorker(); };
  signal?.addEventListener("abort", abort, { once: true });
  try {
    const reply = await request("infer", { rgba: rgba.buffer, mask: maskCopy.buffer }, [rgba.buffer, maskCopy.buffer]);
    if (signal?.aborted) throw new DOMException("AI reconstruction cancelled.", "AbortError");
    if (!reply.rgba) throw new Error("AI worker returned no image data.");
    return { imageData: new ImageData(new Uint8ClampedArray(reply.rgba), image.width, image.height), provider: reply.provider ?? provider, inferenceMs: reply.inferenceMs ?? 0 };
  } finally {
    signal?.removeEventListener("abort", abort);
  }
}

export async function resetAIWorker(): Promise<void> {
  const active = worker;
  worker = null;
  initPromise = null;
  if (!active) return;
  active.terminate();
  const error = new DOMException("AI worker was cancelled or reset.", "AbortError");
  for (const request of pending.values()) request.reject(error);
  pending.clear();
}
