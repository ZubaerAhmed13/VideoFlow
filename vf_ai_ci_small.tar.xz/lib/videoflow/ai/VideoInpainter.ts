import { clipDuration, resolveWatermarkMask, uid } from "../core.mjs";
import { encodeJpegFramesToMp4 } from "../ffmpeg";
import type { ExportSettings, RuntimeAsset, Track, VideoFlowProject, WatermarkMask } from "../types";
import { DEFAULT_AI_SETTINGS, effectiveAISettings, reconstructFrame } from "./AIManager";
import { compositeInpaintedROI } from "./inpainting/InpaintPostprocessor";
import { TemporalContext } from "./temporal/TemporalContext";
import type { AISettings, TrackingPoint } from "./types";

function seekVideo(video: HTMLVideoElement, time: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return Promise.reject(new DOMException("AI render cancelled.", "AbortError"));
  const target = Math.max(0, Math.min(Number.isFinite(video.duration) ? video.duration : time, time));
  if (video.readyState >= 2 && Math.abs(video.currentTime - target) < 0.0005) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const abort = () => { cleanup(); reject(new DOMException("AI render cancelled.", "AbortError")); };
    const loaded = () => { cleanup(); resolve(); };
    const failed = () => { cleanup(); reject(new Error("Could not decode an AI source frame.")); };
    const cleanup = () => {
      signal.removeEventListener("abort", abort);
      video.removeEventListener("seeked", loaded);
      video.removeEventListener("error", failed);
    };
    signal.addEventListener("abort", abort, { once: true });
    video.addEventListener("seeked", loaded, { once: true });
    video.addEventListener("error", failed, { once: true });
    video.currentTime = target;
  });
}

function toBlob(canvas: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Could not encode AI frame.")), "image/jpeg", 0.92));
}

function trackingAt(points: TrackingPoint[] | undefined, time: number): TrackingPoint | null {
  if (!points?.length) return null;
  const sorted = [...points].sort((a, b) => a.time - b.time);
  if (time <= sorted[0].time) return sorted[0];
  if (time >= sorted.at(-1)!.time) return sorted.at(-1)!;
  const nextIndex = sorted.findIndex((point) => point.time >= time);
  const before = sorted[nextIndex - 1], after = sorted[nextIndex];
  const span = Math.max(0.000001, after.time - before.time);
  const ratio = (time - before.time) / span;
  return {
    time,
    x: before.x + (after.x - before.x) * ratio,
    y: before.y + (after.y - before.y) * ratio,
    width: before.width + (after.width - before.width) * ratio,
    height: before.height + (after.height - before.height) * ratio,
    confidence: Math.min(before.confidence ?? 1, after.confidence ?? 1),
    method: before.manual || after.manual ? "manual" : "template",
  };
}

function resolvedAIMask(mask: WatermarkMask, timelineTime: number): WatermarkMask {
  const base = resolveWatermarkMask(mask, timelineTime) as WatermarkMask;
  const tracked = trackingAt(mask.ai?.tracking, timelineTime);
  return tracked ? { ...base, x: tracked.x, y: tracked.y, width: tracked.width, height: tracked.height } : base;
}

function aiSettings(mask: WatermarkMask): AISettings {
  return { ...DEFAULT_AI_SETTINGS, ...(mask.ai ?? {}) } as AISettings;
}

async function renderAIClip(
  project: VideoFlowProject,
  clip: VideoFlowProject["clips"][number],
  asset: RuntimeAsset,
  exportSettings: ExportSettings,
  signal: AbortSignal,
  onProgress: (progress: number, phase: string) => void,
  temporalState?: Map<string, TemporalContext>,
): Promise<RuntimeAsset> {
  const sourceUrl = asset.url ?? (asset.blob ? URL.createObjectURL(asset.blob) : undefined);
  if (!sourceUrl || asset.offline) throw new Error(`AI source ${asset.name} is offline. Relink the original before export.`);
  const revoke = !asset.url && Boolean(asset.blob);
  const video = document.createElement("video");
  video.muted = true;
  video.preload = "auto";
  video.src = sourceUrl;
  try {
    await new Promise<void>((resolve, reject) => {
      video.onloadedmetadata = () => resolve();
      video.onerror = () => reject(new Error(`Could not decode ${asset.name} for AI reconstruction.`));
    });
    const width = asset.width || video.videoWidth || project.settings.width;
    const height = asset.height || video.videoHeight || project.settings.height;
    const fps = Math.max(1, Math.min(exportSettings.fps || project.settings.fps, 60));
    const duration = clipDuration(clip);
    const frameCount = Math.max(1, Math.ceil(duration * fps));
    // Keep each AI-preprocessed clip bounded. The segmented renderer slices long
    // timelines before this point; a single in-memory sequence above 8 seconds
    // would create unnecessary browser pressure.
    if (duration > 8.05) throw new Error("AI preprocessing requires bounded export segments of 8 seconds or less. Use direct-to-disk segmented MP4 or an in/out range.");
    const canvas = document.createElement("canvas");
    canvas.width = width; canvas.height = height;
    const context = canvas.getContext("2d", { alpha: false });
    if (!context) throw new Error("AI composition canvas is unavailable.");
    const frames: Blob[] = [];
    const temporal = temporalState ?? new Map<string, TemporalContext>();
    for (let index = 0; index < frameCount; index += 1) {
      if (signal.aborted) throw new DOMException("AI render cancelled.", "AbortError");
      const localTime = Math.min(duration, index / fps);
      const timelineTime = clip.timelineStart + localTime;
      const sourceTime = clip.sourceStart + localTime * clip.speed;
      await seekVideo(video, sourceTime, signal);
      context.filter = "none";
      context.globalAlpha = 1;
      context.drawImage(video, 0, 0, width, height);
      for (const mask of clip.watermarkMasks.filter((entry) => entry.enabled && entry.method === "ai" && timelineTime >= entry.start && timelineTime <= entry.end)) {
        const resolved = resolvedAIMask(mask, timelineTime);
        const effective = effectiveAISettings(aiSettings(mask));
        let contextWindow = temporal.get(mask.id);
        if (!contextWindow) { contextWindow = new TemporalContext(effective.temporalWindow); temporal.set(mask.id, contextWindow); }
        const result = await reconstructFrame(video, width, height, resolved, effective, contextWindow.history(), signal);
        contextWindow.push(result.sourceROI, result.imageData);
        compositeInpaintedROI(context, result.imageData, result.roi, resolved, effective.feather, effective.blendingStrength);
      }
      frames.push(await toBlob(canvas));
      onProgress((index + 1) / Math.max(1, frameCount) * 0.82, `AI inference frame ${index + 1}/${frameCount}`);
    }
    const blob = await encodeJpegFramesToMp4(frames, fps, signal, (progress, phase) => onProgress(0.82 + progress * 0.18, phase));
    return {
      id: uid("ai-asset"), projectId: project.id, name: `${clip.name}-ai.mp4`, kind: "video", mime: "video/mp4", size: blob.size,
      duration, width, height, createdAt: new Date().toISOString(), signature: "iso-base-media", nativeDecodable: true,
      storageMode: "session", risk: "normal", offline: false, blob, url: URL.createObjectURL(blob),
    };
  } finally {
    video.pause(); video.removeAttribute("src"); video.load(); if (revoke) URL.revokeObjectURL(sourceUrl);
  }
}

export async function prepareAIAssetsForExport(
  project: VideoFlowProject,
  assets: RuntimeAsset[],
  settings: ExportSettings,
  signal: AbortSignal,
  onProgress: (progress: number, phase: string) => void,
  temporalState?: Map<string, TemporalContext>,
): Promise<{ project: VideoFlowProject; assets: RuntimeAsset[]; cleanup: () => void }> {
  const aiClips = project.clips.filter((clip) => clip.kind === "video" && clip.watermarkMasks.some((mask) => mask.enabled && mask.method === "ai"));
  if (!aiClips.length) return { project, assets, cleanup: () => undefined };
  const nextProject = structuredClone(project);
  const nextAssets = [...assets];
  const generated: RuntimeAsset[] = [];
  const audioTrackId = uid("ai-audio-track");
  const audioTrack: Track = { id: audioTrackId, name: "AI source audio", kind: "audio", index: nextProject.tracks.length, muted: false, solo: false, locked: false, visible: true, gain: 1 };
  let addedAudioTrack = false;
  for (let index = 0; index < aiClips.length; index += 1) {
    const sourceClip = aiClips[index];
    const sourceAsset = assets.find((asset) => asset.id === sourceClip.assetId);
    if (!sourceAsset) throw new Error(`AI source asset for ${sourceClip.name} is unavailable.`);
    onProgress(index / aiClips.length * 0.9, `AI preprocessing ${sourceClip.name}`);
    const aiAsset = await renderAIClip(project, sourceClip, sourceAsset, settings, signal, (p, phase) => onProgress((index + p) / aiClips.length * 0.9, phase), temporalState);
    generated.push(aiAsset); nextAssets.push(aiAsset);
    const clipIndex = nextProject.clips.findIndex((entry) => entry.id === sourceClip.id);
    const duration = clipDuration(sourceClip);
    const originalAudio = structuredClone(nextProject.clips[clipIndex]);
    originalAudio.id = uid("ai-audio"); originalAudio.kind = "audio"; originalAudio.trackId = audioTrackId; originalAudio.watermarkMasks = []; originalAudio.keyframes = originalAudio.keyframes.filter((keyframe) => keyframe.property === "volume");
    nextProject.clips[clipIndex] = { ...nextProject.clips[clipIndex], assetId: aiAsset.id, sourceStart: 0, sourceEnd: duration, speed: 1, watermarkMasks: nextProject.clips[clipIndex].watermarkMasks.filter((mask) => mask.method !== "ai") };
    nextProject.clips.push(originalAudio);
    addedAudioTrack = true;
  }
  if (addedAudioTrack) nextProject.tracks.push(audioTrack);
  return { project: nextProject, assets: nextAssets, cleanup: () => generated.forEach((asset) => asset.url && URL.revokeObjectURL(asset.url)) };
}
