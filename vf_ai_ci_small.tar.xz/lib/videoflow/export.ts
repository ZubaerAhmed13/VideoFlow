import { projectDuration } from "./core.mjs";
import { projectForExportRange } from "./export-range.mjs";
import { FORMAT_INFO } from "./ffmpeg-commands.mjs";
import {
  assertCompatibleFragmentInit,
  createFragmentedMp4State,
  mediaChunksForSegment,
} from "./fragmented-mp4.mjs";
import {
  probeMediaBlob,
  renderTimelineFragmentWithFfmpeg,
  renderTimelineWithFfmpeg,
} from "./ffmpeg";
import { assessRenderRisk } from "./import-policy.mjs";
import { prepareAIAssetsForExport } from "./ai/VideoInpainter";
import { TemporalContext } from "./ai/temporal/TemporalContext";
import type {
  ExportJob,
  ExportSettings,
  RuntimeAsset,
  VideoFlowProject,
} from "./types";

type Validation = NonNullable<ExportJob["validation"]>;

export interface RenderExportResult {
  blob?: Blob;
  validation: Validation;
  filename: string;
  diskBacked: boolean;
  fileSize: number;
  segmentCount?: number;
}

export function exportFilename(
  projectName: string,
  settings: ExportSettings,
): string {
  const base =
    projectName.replace(/[^a-z0-9-_]+/gi, "-").replace(/^-+|-+$/g, "") ||
    "videoflow-export";
  return `${base}.${FORMAT_INFO[settings.format].extension}`;
}

function streamDuration(
  stream: { duration?: string },
  fallback: number,
): number {
  const duration = Number(stream.duration ?? fallback);
  return Number.isFinite(duration) ? duration : fallback;
}

export async function validateExport(
  blob: Blob,
  filename: string,
  settings: ExportSettings,
  expectedDuration: number,
  signal: AbortSignal,
): Promise<Validation> {
  if (blob.size < 1024)
    throw new Error("Output validation failed: the encoded file is empty.");
  const probe = await probeMediaBlob(blob, filename, signal);
  const video = probe.streams.find((stream) => stream.codec_type === "video");
  const audio = probe.streams.find((stream) => stream.codec_type === "audio");
  const audioOnly = ["wav", "mp3", "opus"].includes(settings.format);
  const expectsVideo = !audioOnly;
  const expectsAudio =
    audioOnly || (settings.includeAudio && settings.format !== "gif");
  if (expectsVideo && !video)
    throw new Error("Output validation failed: the video stream is missing.");
  if (expectsAudio && !audio)
    throw new Error("Output validation failed: the audio stream is missing.");
  if (!expectsAudio && audio)
    throw new Error(
      "Output validation failed: an audio stream was present after Remove Audio.",
    );
  const duration = Number(
    probe.format?.duration ??
      streamDuration(video ?? audio ?? {}, expectedDuration),
  );
  if (!Number.isFinite(duration) || duration <= 0)
    throw new Error(
      "Output validation failed: duration metadata is unreadable.",
    );
  if (
    expectedDuration > 0 &&
    Math.abs(duration - expectedDuration) > Math.max(2, expectedDuration * 0.02)
  ) {
    throw new Error(
      `Output validation failed: duration ${duration.toFixed(2)}s differs from the ${expectedDuration.toFixed(2)}s timeline.`,
    );
  }
  if (
    video &&
    settings.format !== "gif" &&
    (video.width !== settings.width || video.height !== settings.height)
  ) {
    throw new Error(
      `Output validation failed: expected ${settings.width}×${settings.height}, received ${video.width ?? 0}×${video.height ?? 0}.`,
    );
  }
  return {
    duration,
    width: video?.width,
    height: video?.height,
    videoCodec: video?.codec_name,
    audioCodec: audio?.codec_name,
    hasVideo: Boolean(video),
    hasAudio: Boolean(audio),
  };
}

function renderRiskFor(
  project: VideoFlowProject,
  settings: ExportSettings,
  duration: number,
) {
  return assessRenderRisk({
    width: settings.width,
    height: settings.height,
    fps: settings.fps,
    duration,
    videoBitrate: settings.videoBitrate,
    clipCount: project.clips.length,
    effectComplexity: project.clips.some(
      (clip) => clip.watermarkMasks.length || clip.keyframes.length,
    )
      ? 1.6
      : 1,
    aiEffects: project.clips.some((clip) => clip.watermarkMasks.some((mask) => mask.method === "ai")),
    directDiskAvailable: typeof window !== "undefined" && typeof window.showSaveFilePicker === "function",
    deviceMemoryGb: typeof navigator !== "undefined" ? Number((navigator as Navigator & { deviceMemory?: number }).deviceMemory) : undefined,
  });
}

async function clearFailedDiskOutput(handle: FileSystemFileHandle): Promise<void> {
  try {
    const writable = await handle.createWritable();
    await writable.truncate(0);
    await writable.close();
  } catch {
    // The original render error remains primary. A browser may revoke write
    // permission between the failed render and cleanup.
  }
}

async function renderDiskBackedMp4(
  project: VideoFlowProject,
  assets: RuntimeAsset[],
  settings: ExportSettings,
  targetHandle: FileSystemFileHandle,
  signal: AbortSignal,
  onProgress: (progress: number, phase: string) => void,
): Promise<RenderExportResult> {
  if (settings.format !== "mp4") {
    throw new Error(
      "Direct disk-backed segmented export currently supports MP4/H.264 only. Use standard export for other formats.",
    );
  }
  const duration = projectDuration(project);
  const risk = renderRiskFor(project, settings, duration);
  const hasAI = project.clips.some((clip) => clip.watermarkMasks.some((mask) => mask.enabled && mask.method === "ai"));
  const segmentSeconds = hasAI
    ? Math.min(8, Math.max(2, risk.segmentSeconds))
    : Math.max(
        5,
        Math.min(
          300,
          risk.level === "very-high" ? Math.min(60, risk.segmentSeconds) : risk.segmentSeconds,
        ),
      );
  const segmentCount = Math.max(1, Math.ceil(duration / segmentSeconds));
  const filename = exportFilename(project.name, settings);
  let writable: Awaited<ReturnType<FileSystemFileHandle["createWritable"]>> | null = null;
  let closed = false;
  let bytesWritten = 0;
  let state: ReturnType<typeof createFragmentedMp4State> | null = null;
  const aiTemporalState = new Map<string, TemporalContext>();

  try {
    onProgress(0.01, `Preparing bounded export • ${segmentCount} segment${segmentCount === 1 ? "" : "s"}`);
    writable = await targetHandle.createWritable();
    for (let index = 0; index < segmentCount; index += 1) {
      if (signal.aborted) throw new DOMException("Export cancelled.", "AbortError");
      const start = index * segmentSeconds;
      const end = Math.min(duration, start + segmentSeconds);
      const segmentProject = projectForExportRange(project, start, end);
      const baseProgress = index / segmentCount;
      const aiPrepared = await prepareAIAssetsForExport(
        segmentProject,
        assets,
        settings,
        signal,
        (aiProgress, phase) => onProgress(0.02 + (baseProgress + aiProgress / segmentCount) * 0.36, phase),
        aiTemporalState,
      );
      let segmentBlob: Blob;
      try {
        segmentBlob = await renderTimelineFragmentWithFfmpeg(
          aiPrepared.project,
          aiPrepared.assets,
          settings,
          signal,
          (segmentProgress, phase) => {
            const overall = 0.02 + (baseProgress + segmentProgress / segmentCount) * 0.86;
            onProgress(
              Math.min(0.88, overall),
              `Segment ${index + 1}/${segmentCount} • ${phase}`,
            );
          },
        );
      } finally {
        aiPrepared.cleanup();
      }
      const segmentBytes = new Uint8Array(await segmentBlob.arrayBuffer());
      if (!state) {
        state = createFragmentedMp4State(segmentBytes);
        await writable.write(state.initSegment);
        bytesWritten += state.initSegment.byteLength;
      } else {
        assertCompatibleFragmentInit(segmentBytes, state);
      }
      const chunks = mediaChunksForSegment(segmentBytes, state, start);
      for (const chunk of chunks) {
        if (signal.aborted) throw new DOMException("Export cancelled.", "AbortError");
        await writable.write(chunk);
        bytesWritten += chunk.byteLength;
      }
      onProgress(
        0.02 + ((index + 1) / segmentCount) * 0.86,
        `Wrote segment ${index + 1}/${segmentCount} directly to disk`,
      );
    }
    await writable.close();
    closed = true;
    onProgress(0.9, "Validating disk-backed MP4");
    const outputFile = await targetHandle.getFile();
    const validation = await validateExport(
      outputFile,
      filename,
      settings,
      duration,
      signal,
    );
    aiTemporalState.clear();
    onProgress(1, "Complete • saved directly to disk");
    return {
      validation,
      filename,
      diskBacked: true,
      fileSize: outputFile.size || bytesWritten,
      segmentCount,
    };
  } catch (error) {
    aiTemporalState.clear();
    if (writable && !closed) {
      try {
        const abortable = writable as typeof writable & { abort?: (reason?: unknown) => Promise<void> };
        if (typeof abortable.abort === "function") await abortable.abort(error);
        else await writable.close();
      } catch {
        // Cleanup is best-effort; the thrown render error is more useful.
      }
    }
    await clearFailedDiskOutput(targetHandle);
    if (signal.aborted) throw new DOMException("Export cancelled.", "AbortError");
    throw error;
  }
}

export async function renderExport(
  project: VideoFlowProject,
  assets: RuntimeAsset[],
  settings: ExportSettings,
  signal: AbortSignal,
  onProgress: (progress: number, phase: string) => void,
  targetHandle?: FileSystemFileHandle,
): Promise<RenderExportResult> {
  const rangedProject = projectForExportRange(
    project,
    settings.rangeStart ?? 0,
    settings.rangeEnd ?? projectDuration(project),
  );
  const configuredProject: VideoFlowProject = {
    ...rangedProject,
    settings: {
      ...rangedProject.settings,
      width: settings.width,
      height: settings.height,
      fps: settings.fps,
    },
  };
  const duration = projectDuration(configuredProject);
  if (duration <= 0) throw new Error("The timeline is empty.");

  if (targetHandle) {
    return renderDiskBackedMp4(
      configuredProject,
      assets,
      settings,
      targetHandle,
      signal,
      onProgress,
    );
  }

  const risk = renderRiskFor(configuredProject, settings, duration);
  if (!risk.inMemoryAllowed) {
    throw new Error(risk.recommendation);
  }

  onProgress(0.01, "Preparing sources");
  const aiPrepared = await prepareAIAssetsForExport(
    configuredProject,
    assets,
    settings,
    signal,
    (progress, phase) => onProgress(0.02 + progress * 0.42, phase),
  );
  let blob: Blob;
  try {
    blob = await renderTimelineWithFfmpeg(
      aiPrepared.project,
      aiPrepared.assets,
      settings,
      signal,
      (progress, phase) => onProgress(0.44 + progress * 0.48, phase),
    );
  } finally {
    aiPrepared.cleanup();
  }
  const filename = exportFilename(project.name, settings);
  onProgress(0.94, "Validating container and streams");
  const validation = await validateExport(
    blob,
    filename,
    settings,
    duration,
    signal,
  );
  onProgress(1, "Complete");
  return {
    blob,
    validation,
    filename,
    diskBacked: false,
    fileSize: blob.size,
  };
}
