# VideoFlow AI Reconstruction Pack

The certified AI release stages the checksum-pinned LaMa 512 INT8 ONNX model into `dist/models/lama-512-int8.onnx` during CI. The large generated binary is intentionally not duplicated in the source portion of the release archive.

Model metadata:

- Model: LaMa 512 INT8 ONNX
- License: Apache-2.0
- Expected SHA-256: `cab19978adc306622fe37ef60d4a52103b99c98141d499c2a2366a7ed1255dbe`
- Browser runtime: ONNX Runtime Web 1.29.0
- Staging script: `scripts/stage-ai-pack-ci.sh`

The app validates the model checksum before installing it into the local AI cache. After local installation, inference works without cloud processing. Blur, pixelate, cover and clone remain available even if the model is removed.
