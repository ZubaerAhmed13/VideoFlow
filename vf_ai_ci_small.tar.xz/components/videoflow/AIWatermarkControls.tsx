"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Activity, CheckCircle2, Cpu, LoaderCircle, Sparkles, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DEFAULT_AI_SETTINGS, effectiveAISettings, reconstructFrame } from "@/lib/videoflow/ai/AIManager";
import { resetAIWorker } from "@/lib/videoflow/ai/AIWorkerClient";
import { compositeInpaintedROI } from "@/lib/videoflow/ai/inpainting/InpaintPostprocessor";
import { detectAICapability } from "@/lib/videoflow/ai/AICapability";
import { bundledAIModelAvailable, getAIModelRecord, installAIModel, installBundledAIModel, removeAIModel } from "@/lib/videoflow/ai/AIModelLoader";
import { DEFAULT_AI_MODEL } from "@/lib/videoflow/ai/AIModelRegistry";
import { installAIRuntime, removeAIRuntime, runtimeAvailability } from "@/lib/videoflow/ai/AIRuntimeInstaller";
import { trackTemplate } from "@/lib/videoflow/ai/tracking/TemplateTracker";
import type { AIQuality, AISettings, TrackingPoint } from "@/lib/videoflow/ai/types";
import { loadAIDefaultSettings } from "@/lib/videoflow/ai/AISettingsStore";
import type { Clip, RuntimeAsset, WatermarkMask } from "@/lib/videoflow/types";

function frameAt(video: HTMLVideoElement, time: number, signal?: AbortSignal): Promise<ImageBitmap> {
  if (signal?.aborted) return Promise.reject(new DOMException("AI job cancelled.", "AbortError"));
  return new Promise((resolve, reject) => {
    const onAbort = () => { cleanup(); reject(new DOMException("AI job cancelled.", "AbortError")); };
    const onSeeked = async () => {
      cleanup();
      try { resolve(await createImageBitmap(video)); } catch (error) { reject(error); }
    };
    const onError = () => { cleanup(); reject(new Error("Could not decode the selected AI preview frame.")); };
    const cleanup = () => { video.removeEventListener("seeked", onSeeked); video.removeEventListener("error", onError); signal?.removeEventListener("abort", onAbort); };
    signal?.addEventListener("abort", onAbort, { once: true });
    video.addEventListener("seeked", onSeeked, { once: true });
    video.addEventListener("error", onError, { once: true });
    video.currentTime = Math.max(0, Math.min(Number.isFinite(video.duration) ? video.duration : time, time));
  });
}

function maskSettings(mask: WatermarkMask): AISettings {
  return { ...DEFAULT_AI_SETTINGS, ...loadAIDefaultSettings(), ...(mask.ai ?? {}) } as AISettings;
}

export function AIWatermarkControls({ clip, mask, asset, playhead, updateMask }: {
  clip: Clip;
  mask: WatermarkMask;
  asset?: RuntimeAsset;
  playhead: number;
  updateMask: (patch: Partial<WatermarkMask>, label?: string) => void;
}) {
  const modelInput = useRef<HTMLInputElement>(null);
  const runtimeInput = useRef<HTMLInputElement>(null);
  const jobController = useRef<AbortController | null>(null);
  const [record, setRecord] = useState(() => getAIModelRecord());
  const [runtimeReady, setRuntimeReady] = useState(false);
  const [bundledModel, setBundledModel] = useState(false);
  const [provider, setProvider] = useState("Checking…");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const settings = useMemo(() => maskSettings(mask), [mask]);
  useEffect(() => {
    void Promise.all([runtimeAvailability(), detectAICapability(), bundledAIModelAvailable()]).then(([runtime, capability, bundled]) => {
      setRuntimeReady(runtime.ready);
      setBundledModel(bundled);
      setProvider(capability.webgpu === "available" ? "WebGPU available" : `WASM fallback • WebGPU ${capability.webgpu}`);
    });
  }, []);

  const patchAI = (patch: Partial<AISettings>) => updateMask({ ai: { modelId: DEFAULT_AI_MODEL.id, modelVersion: DEFAULT_AI_MODEL.version, ...settings, ...patch } }, "AI settings changed");

  const installModel = async (file?: File) => {
    if (!file) return;
    setBusy(true); setError(null); setProgress("Validating model checksum…");
    try { setRecord(await installAIModel(file)); setProgress("Model installed locally."); }
    catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  const installBundled = async () => {
    setBusy(true); setError(null); setProgress("Validating bundled AI model…");
    try { setRecord(await installBundledAIModel()); setProgress("Bundled AI model installed locally and checksum verified."); }
    catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  const installRuntime = async (files?: FileList | null) => {
    if (!files?.length) return;
    setBusy(true); setError(null); setProgress("Installing local ONNX runtime…");
    try {
      const result = await installAIRuntime(files);
      const status = await runtimeAvailability(); setRuntimeReady(status.ready);
      setProgress(result.missing.length ? `Runtime partial: missing ${result.missing.join(", ")}.` : "Runtime installed. Reload once before first inference.");
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { setBusy(false); }
  };

  const preview = async () => {
    if (!asset?.url || asset.offline) { setError("Original/proxy media is offline. Relink it before AI preview."); return; }
    const controller = new AbortController(); jobController.current = controller;
    setBusy(true); setError(null); setProgress("Decoding current frame…");
    const video = document.createElement("video"); video.muted = true; video.preload = "auto"; video.src = asset.proxyUrl ?? asset.url;
    try {
      await new Promise<void>((resolve, reject) => { video.onloadedmetadata = () => resolve(); video.onerror = () => reject(new Error("Could not open media for AI preview.")); });
      const sourceTime = clip.sourceStart + Math.max(0, playhead - clip.timelineStart) * clip.speed;
      const bitmap = await frameAt(video, sourceTime, controller.signal);
      setProgress("Running genuine ONNX inpainting…");
      const result = await reconstructFrame(bitmap, bitmap.width, bitmap.height, mask, settings, null, controller.signal);
      const canvas = document.createElement("canvas"); canvas.width = bitmap.width; canvas.height = bitmap.height;
      const ctx = canvas.getContext("2d")!; ctx.drawImage(bitmap, 0, 0);
      const effective = effectiveAISettings(settings);
      compositeInpaintedROI(ctx, result.imageData, result.roi, mask, effective.feather, effective.blendingStrength);
      bitmap.close(); setPreviewUrl(canvas.toDataURL("image/jpeg", 0.9)); setProgress(`${result.provider.toUpperCase()} inference • ${Math.round(result.inferenceMs)} ms • ROI ${result.roi.width}×${result.roi.height}`);
      updateMask({ method: "ai", ai: { modelId: DEFAULT_AI_MODEL.id, modelVersion: DEFAULT_AI_MODEL.version, ...settings } }, "AI reconstruction enabled");
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { if (jobController.current === controller) jobController.current = null; setBusy(false); video.removeAttribute("src"); video.load(); }
  };

  const track = async (direction: "forward" | "backward") => {
    if (!asset?.url || asset.offline) { setError("Media is offline. Relink before tracking."); return; }
    const controller = new AbortController(); jobController.current = controller;
    setBusy(true); setError(null); setProgress("Tracking watermark on proxy/source…");
    const video = document.createElement("video"); video.muted = true; video.preload = "auto"; video.src = asset.proxyUrl ?? asset.url;
    const frames: Array<{ time: number; image: ImageBitmap }> = [];
    try {
      await new Promise<void>((resolve, reject) => { video.onloadedmetadata = () => resolve(); video.onerror = () => reject(new Error("Could not decode media for tracking.")); });
      const anchor = Math.max(mask.start, Math.min(mask.end, playhead));
      const start = direction === "forward" ? anchor : Math.max(mask.start, anchor - 2);
      const end = direction === "forward" ? Math.min(mask.end, anchor + 2) : anchor;
      const times: number[] = [];
      if (direction === "forward") for (let t = start; t <= end + 1e-6; t += 0.2) times.push(t);
      else for (let t = end; t >= start - 1e-6; t -= 0.2) times.push(t);
      for (const t of times) {
        const sourceTime = clip.sourceStart + Math.max(0, t - clip.timelineStart) * clip.speed;
        if (controller.signal.aborted) throw new DOMException("Tracking cancelled.", "AbortError");
        frames.push({ time: t, image: await frameAt(video, sourceTime, controller.signal) });
      }
      const initial: TrackingPoint = { time: frames[0]?.time ?? start, x: mask.x, y: mask.y, width: mask.width, height: mask.height, confidence: 1, method: "manual", manual: true };
      const points = (await trackTemplate(frames, initial)).sort((a, b) => a.time - b.time);
      patchAI({ trackingMethod: "template" });
      updateMask({ ai: { modelId: DEFAULT_AI_MODEL.id, modelVersion: DEFAULT_AI_MODEL.version, ...settings, trackingMethod: "template", tracking: points } }, "Watermark tracked");
      const avg = points.reduce((s, p) => s + (p.confidence ?? 1), 0) / Math.max(1, points.length);
      const low = points.filter((point) => (point.confidence ?? 1) < 0.55);
      setProgress(`Tracking ${direction} complete • ${points.length} points • average confidence ${Math.round(avg * 100)}%${low.length ? ` • ${low.length} low-confidence point${low.length === 1 ? "" : "s"} require review` : ""}`);
    } catch (e) { setError(e instanceof Error ? e.message : String(e)); }
    finally { if (jobController.current === controller) jobController.current = null; frames.forEach((frame) => frame.image.close()); setBusy(false); video.removeAttribute("src"); video.load(); }
  };

  return <div className="vf-ai-panel">
    <div className="vf-ai-status"><Sparkles /><div><strong>AI Reconstruction</strong><span>{record.state === "not-installed" ? "Model not installed" : `${record.descriptor.name} • ${record.state}`}</span></div><b className={record.state === "installed" || record.state === "ready" ? "supported" : "limited"}>{runtimeReady ? provider : "Runtime pack required"}</b></div>
    <p className="vf-note">Local-only neural reconstruction. Use only on media you own or are authorized to modify. Reconstruction creates plausible pixels; it cannot recover permanently hidden originals.</p>
    {mask.ai?.modelVersion && mask.ai.modelVersion !== DEFAULT_AI_MODEL.version && (
      <p className="vf-note vf-error">This project used AI model {mask.ai.modelVersion}; installed release model is {DEFAULT_AI_MODEL.version}. Preview the result before export because neural output can change between model versions.</p>
    )}
    <input ref={modelInput} hidden type="file" accept=".onnx,application/octet-stream" onChange={(e) => void installModel(e.target.files?.[0])}/>
    <input ref={runtimeInput} hidden type="file" multiple accept=".mjs,.wasm,application/wasm,text/javascript" onChange={(e) => void installRuntime(e.target.files)}/>
    <div className="vf-button-grid">
      {bundledModel && record.state === "not-installed" && <Button size="sm" disabled={busy} onClick={() => void installBundled()}><Sparkles /> Install bundled AI</Button>}
      <Button variant="outline" size="sm" onClick={() => modelInput.current?.click()}><Upload /> Install model file</Button>
      <Button variant="outline" size="sm" onClick={() => runtimeInput.current?.click()}><Cpu /> Install runtime</Button>
      <Button variant="outline" size="sm" onClick={() => void Promise.all([removeAIModel(), removeAIRuntime()]).then(() => { setRecord(getAIModelRecord()); setRuntimeReady(false); setProgress("AI model/runtime removed from local storage."); })}><Trash2 /> Remove AI</Button>
    </div>
    <div className="vf-mask-fields">
      <label>Quality<select value={settings.quality} onChange={(e) => patchAI({ quality: e.target.value as AIQuality })}><option value="fast">Fast</option><option value="balanced">Balanced</option><option value="high">High</option><option value="maximum">Maximum</option></select></label>
      <label>Provider<select value={settings.provider} onChange={(e) => patchAI({ provider: e.target.value as AISettings["provider"] })}><option value="auto">Automatic</option><option value="webgpu">WebGPU</option><option value="wasm">WASM</option></select></label>
      <label>Temporal window<input type="number" min={1} max={17} step={2} value={settings.temporalWindow} onChange={(e) => patchAI({ temporalWindow: Math.max(1, Number(e.target.value) | 1) })}/></label>
      <label>ROI padding<input type="number" min={16} max={256} value={settings.roiPadding} onChange={(e) => patchAI({ roiPadding: Number(e.target.value) })}/></label>
    </div>
    <div className="vf-button-grid">
      <Button size="sm" disabled={busy || record.state === "not-installed" || !runtimeReady} onClick={() => void preview()}>{busy ? <LoaderCircle className="animate-spin"/> : <Sparkles/>} Preview current frame</Button>
      <Button variant="outline" size="sm" disabled={busy || !asset} onClick={() => void track("forward")}><Activity/> Track Forward</Button>
      <Button variant="outline" size="sm" disabled={busy || !asset} onClick={() => void track("backward")}><Activity/> Track Backward</Button>
      {busy && <Button variant="destructive" size="sm" onClick={() => { jobController.current?.abort(); void resetAIWorker(); setProgress("Cancelling AI job…"); }}>Cancel AI Job</Button>}
    </div>
    {previewUrl && <img className="vf-ai-preview" src={previewUrl} alt="AI reconstruction current-frame preview" />}
    {progress && <div className="vf-note"><CheckCircle2 /> {progress}</div>}
    {error && <div className="vf-note vf-error">{error}</div>}
  </div>;
}
