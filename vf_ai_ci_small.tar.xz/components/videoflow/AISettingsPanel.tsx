"use client";

import { useEffect, useRef, useState } from "react";
import { Activity, Cpu, LoaderCircle, ShieldCheck, Sparkles, Trash2, Upload } from "lucide-react";

import { Button } from "@/components/ui/button";
import { detectAICapability, type AICapabilityReport } from "@/lib/videoflow/ai/AICapability";
import { runImageInpainting, resetAISession } from "@/lib/videoflow/ai/AIInferenceEngine";
import {
  bundledAIModelAvailable,
  getAIModelRecord,
  installAIModel,
  installBundledAIModel,
  removeAIModel,
} from "@/lib/videoflow/ai/AIModelLoader";
import { DEFAULT_AI_MODEL } from "@/lib/videoflow/ai/AIModelRegistry";
import {
  installAIRuntime,
  removeAIRuntime,
  runtimeAvailability,
} from "@/lib/videoflow/ai/AIRuntimeInstaller";
import {
  loadAIDefaultSettings,
  saveAIDefaultSettings,
} from "@/lib/videoflow/ai/AISettingsStore";
import type { AIProvider, AIQuality, AISettings } from "@/lib/videoflow/ai/types";

export function AISettingsPanel() {
  const modelInput = useRef<HTMLInputElement>(null);
  const runtimeInput = useRef<HTMLInputElement>(null);
  const [defaults, setDefaults] = useState<AISettings>(() => loadAIDefaultSettings());
  const [model, setModel] = useState(() => getAIModelRecord());
  const [runtimeReady, setRuntimeReady] = useState(false);
  const [bundled, setBundled] = useState(false);
  const [capability, setCapability] = useState<AICapabilityReport | null>(null);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("Checking local AI…");

  const refresh = async () => {
    const [runtime, detected, hasBundled] = await Promise.all([
      runtimeAvailability(),
      detectAICapability(),
      bundledAIModelAvailable(),
    ]);
    setRuntimeReady(runtime.ready);
    setCapability(detected);
    setBundled(hasBundled);
    setModel(getAIModelRecord());
    setStatus("AI state refreshed.");
  };

  useEffect(() => {
    void refresh();
  }, []);

  const patchDefaults = (patch: Partial<AISettings>) => {
    const next = { ...defaults, ...patch };
    setDefaults(next);
    saveAIDefaultSettings(next);
  };

  const installBundled = async () => {
    setBusy(true);
    setStatus("Validating bundled LaMa checksum…");
    try {
      const record = await installBundledAIModel();
      setModel(record);
      setStatus("Model installed locally and checksum verified.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  };

  const installModel = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    setStatus("Validating selected ONNX model…");
    try {
      setModel(await installAIModel(file));
      setStatus("Model installed locally and checksum verified.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  };

  const installRuntime = async (files?: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    setStatus("Installing local ONNX Runtime Web assets…");
    try {
      const result = await installAIRuntime(files);
      const current = await runtimeAvailability();
      setRuntimeReady(current.ready);
      setStatus(result.missing.length ? `Runtime incomplete: missing ${result.missing.join(", ")}.` : "Runtime installed locally.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : String(error));
    } finally {
      setBusy(false);
    }
  };

  const selfTest = async () => {
    setBusy(true);
    setStatus("Running genuine 512×512 neural inference self-test…");
    try {
      await resetAISession();
      const image = new ImageData(512, 512);
      for (let y = 0; y < 512; y += 1) {
        for (let x = 0; x < 512; x += 1) {
          const i = (y * 512 + x) * 4;
          image.data[i] = 40 + Math.round((x / 511) * 150);
          image.data[i + 1] = 70 + Math.round((y / 511) * 120);
          image.data[i + 2] = 140;
          image.data[i + 3] = 255;
        }
      }
      const mask = new Float32Array(512 * 512);
      for (let y = 204; y < 308; y += 1) for (let x = 180; x < 332; x += 1) mask[y * 512 + x] = 1;
      const result = await runImageInpainting(image, mask, defaults);
      setStatus(`PASS • real ${result.provider.toUpperCase()} inference completed in ${Math.round(result.inferenceMs)} ms.`);
    } catch (error) {
      setStatus(`FAIL • ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    if (!window.confirm("Remove the locally cached AI model and runtime? Basic Blur, Pixelate, Cover and Clone remain available.")) return;
    setBusy(true);
    try {
      await Promise.all([removeAIModel(), removeAIRuntime(), resetAISession()]);
      await refresh();
      setStatus("AI model/runtime removed from local storage.");
    } finally {
      setBusy(false);
    }
  };

  const installed = model.state === "installed" || model.state === "ready";
  return (
    <section className="vf-ai-settings">
      <h2><Sparkles /> AI Reconstruction</h2>
      <p>Local neural inpainting only. Use watermark reconstruction only on media you own or are authorized to modify.</p>
      <div className="vf-ai-status">
        <ShieldCheck />
        <div>
          <strong>{DEFAULT_AI_MODEL.name}</strong>
          <span>{installed ? "Checksum-verified model installed" : bundled ? "Bundled model available to install" : "Model not installed"}</span>
        </div>
      </div>
      <div className="vf-ai-status">
        <Cpu />
        <div>
          <strong>ONNX Runtime Web</strong>
          <span>{runtimeReady ? "Local runtime ready" : "Runtime not fully available"} • WebGPU {capability?.webgpu ?? "checking"} • WASM {capability?.wasm === false ? "unavailable" : "available"}</span>
        </div>
      </div>
      <div className="vf-ai-settings-fields">
        <label>
          <span>Provider</span>
          <select value={defaults.provider} onChange={(event) => patchDefaults({ provider: event.target.value as "auto" | AIProvider })}>
            <option value="auto">Automatic</option>
            <option value="webgpu">WebGPU</option>
            <option value="wasm">WASM</option>
          </select>
        </label>
        <label>
          <span>Default quality</span>
          <select value={defaults.quality} onChange={(event) => patchDefaults({ quality: event.target.value as AIQuality })}>
            <option value="fast">Fast</option>
            <option value="balanced">Balanced</option>
            <option value="high">High</option>
            <option value="maximum">Maximum</option>
          </select>
        </label>
        <label>
          <span>Maximum temporal window</span>
          <select value={defaults.temporalWindow} onChange={(event) => patchDefaults({ temporalWindow: Number(event.target.value) })}>
            <option value={3}>3 frames</option>
            <option value={9}>9 frames</option>
            <option value={11}>11 frames</option>
            <option value={15}>15 frames</option>
          </select>
        </label>
      </div>
      <div className="vf-storage-actions">
        {bundled && !installed && <Button disabled={busy} onClick={() => void installBundled()}>{busy ? <LoaderCircle className="animate-spin" /> : <Sparkles />} Install bundled AI</Button>}
        <Button variant="outline" disabled={busy} onClick={() => modelInput.current?.click()}><Upload /> Install model file</Button>
        <Button variant="outline" disabled={busy} onClick={() => runtimeInput.current?.click()}><Upload /> Install runtime files</Button>
        <Button variant="outline" disabled={busy || !installed || !runtimeReady} onClick={() => void selfTest()}><Activity /> Run AI self-test</Button>
        <Button variant="destructive" disabled={busy || (!installed && !runtimeReady)} onClick={() => void remove()}><Trash2 /> Remove AI model</Button>
      </div>
      <input ref={modelInput} hidden type="file" accept=".onnx,application/octet-stream" onChange={(event) => void installModel(event.target.files?.[0])} />
      <input ref={runtimeInput} hidden multiple type="file" accept=".mjs,.wasm,application/wasm,text/javascript" onChange={(event) => void installRuntime(event.target.files)} />
      <p className="vf-note">{status}</p>
    </section>
  );
}
