# VideoFlow AI Reconstruction Pack

The core package intentionally does not auto-download a large model. Install a locally obtained, license-compatible model from Settings/Watermark Studio.

Certified descriptor target:
- Model: LaMa 512 INT8 (`lama_512_int8.onnx`)
- License: Apache-2.0
- SHA-256: `cab19978adc306622fe37ef60d4a52103b99c98141d499c2a2366a7ed1255dbe`
- Expected size: ~62.1 MB

ONNX Runtime Web runtime files must be hosted locally in `public/vendor/onnx/` for production use. VideoFlow never uploads media, masks, or model tensors.
