# VideoFlow Professional Core 1.0.0 — Large Media Certification

Certification date: 2026-08-30

## Final status

**NOT CERTIFIED** under the strict master release definition because the complete browser lifecycle (import → proxy → save → browser close/reopen → relink → browser-WASM bounded original-source render) cannot be executed in this restricted environment.

The architecture and genuine multi-GiB/native-render evidence below are complete and pass. This status must not be changed to CERTIFIED merely because a file-size constant or sparse fixture exists.

## Test machine

- OS: Debian GNU/Linux 13 (trixie)
- Kernel: Linux 6.18.35 x86_64
- CPU: 5 vCPUs, Intel Xeon Platinum 8370C @ 2.80 GHz
- RAM: approximately 5.9 GiB
- Browser available: Chromium 144.0.7559.96, but navigation is administratively blocked
- System FFmpeg: 7.1.5
- GPU: not relied upon; no fabricated GPU-memory claim

## Source media

### Real 4K fixture

- file: `tests/fixtures/generated/uhd-4k-5s.mp4`
- size: 13,429,116 bytes
- resolution: 3840×2160
- video: H.264
- audio: AAC
- frame rate: 24 fps
- duration: 5.000 s

### Multi-GiB certification fixture

- file generated for certification: `outputs/certification/large-3gb-4k-sparse.mp4`
- logical size: 3,221,225,472 bytes (3 GiB)
- physical allocation remains sparse to avoid shipping a multi-GiB duplicate fixture
- resolution: 3840×2160
- video: H.264
- audio: AAC
- frame rate: 24 fps
- duration: 5.000 s
- `ffprobe`: PASS

The fixture is a valid MP4 with a sparse extension and is used to exercise real File-size/File-handle behavior. It is not represented as proof of a long-duration 3 GiB encode.

## Storage/reference architecture

PASS:

- explicit `persisted`, `reference`, and `session` modes
- large/high-risk sources prefer persistent file references when File System Access is available
- non-persisted originals are stripped from IndexedDB media records
- metadata/fingerprint survives without the original Blob
- persistent FileSystemFileHandle is stored where browser support permits
- fallback relinking compares filename/size/metadata/fingerprint and does not silently accept a suspicious replacement
- session/reference originals reopen as offline instead of deleting the timeline asset
- persisted proxies remain independently available
- final original-quality export is blocked until required originals are online

## Proxy architecture

PASS structurally:

- Low: 640×360 / 24 fps
- Balanced: 960×540 / 30 fps
- High: 1280×720 / 30 fps
- proxy duration/source duration metadata is retained
- proxy storage is independent of original-source storage
- preview and waveform processing prefer proxy media when available
- waveform pyramid provides multiple resolutions rather than one unbounded array

Proxy creation time/size for the 3 GiB browser workflow is **NOT VERIFIED** because the browser runtime is unavailable.

## Bounded original-source rendering

PASS at implementation/integration level:

- render risk is estimated from resolution, fps, bitrate, duration, clip/effect complexity and browser path
- MP4 direct-to-disk mode plans adaptive segments
- each segment is encoded once at final settings as fragmented MP4
- init/media fragments are parsed, sequence/timestamps are adjusted and fragments are written incrementally with `FileSystemWritableFileStream`
- JavaScript does not retain all encoded segments simultaneously in direct-to-disk mode
- a compatibility check prevents concatenating incompatible init segments
- boundary range projection preserves interpolated property keyframes and watermark geometry
- standard in-memory export is blocked for estimated multi-GiB output rather than attempting a giant `readFile()` → Blob path

A real integration test creates multiple fragmented MP4 pieces and joins them into a decodable approximately 6-second file.

## Range-render evidence from the 3 GiB source

System-native verification output:

- result: `outputs/certification/large-3gb-range-output.mp4`
- resolution: 3840×2160
- duration: 1.000 s
- video: H.264
- audio: AAC
- size: 3,093,556 bytes
- elapsed: 0:01.92
- maximum RSS observed: 816,092 KiB
- `ffprobe`: PASS

This proves that the genuine 3 GiB logical source can be opened and an original-resolution range can be decoded/effected/encoded by the host FFmpeg path. It does **not** replace the required browser-WASM lifecycle test.

## Required browser lifecycle status

| Step | Status |
| --- | --- |
| Import ~3 GiB source in browser | NOT VERIFIED |
| Choose/reference original | PASS architecture / NOT VERIFIED runtime |
| Avoid full IndexedDB copy | PASS structural test |
| Generate proxy | PASS implementation / NOT VERIFIED on 3 GiB browser source |
| Save project | PASS implementation / NOT VERIFIED runtime |
| Close/reopen browser | PASS architecture / NOT VERIFIED runtime |
| Restore persisted proxy | PASS structural test / NOT VERIFIED runtime |
| Auto reconnect or mark original offline | PASS structural test / NOT VERIFIED runtime |
| Relink original | PASS implementation / NOT VERIFIED runtime |
| Browser bounded original-quality range render | NOT VERIFIED |
| Browser output validation | NOT VERIFIED |
| Temporary-resource cleanup | PASS implementation / NOT VERIFIED runtime |

## Risk notes

Practical limits depend on browser, codec, duration, device RAM, available disk/storage quota and whether direct-to-disk File System Access is available. VideoFlow therefore uses the product wording **large-media optimized**, not “unlimited file size.”
