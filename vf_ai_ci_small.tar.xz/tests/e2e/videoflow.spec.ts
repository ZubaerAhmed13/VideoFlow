import { expect, test, type Page } from "@playwright/test";
import { execFileSync } from "node:child_process";
import { appendFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();
const generated = join(root, "tests", "fixtures", "generated");
const fixture = join(generated, "overlap-source.mp4");
const tone = join(generated, "tone.wav");
const image = join(generated, "overlay.png");


function recordBrowserEvidence(entry: Record<string, unknown>) {
  const dir = join(root, "ci-results");
  mkdirSync(dir, { recursive: true });
  appendFileSync(join(dir, "browser-capabilities.jsonl"), `${JSON.stringify(entry)}\n`);
}

async function importMedia(page: Page, files: string | string[]) {
  await page.getByTestId("media-import").setInputFiles(files);
  await expect(page.getByText(/local file.* imported/i)).toBeVisible();
}

async function queueMp4(page: Page, preset?: string) {
  await page.getByRole("button", { name: "Export", exact: true }).last().click();
  await expect(page.getByText("Export preflight")).toBeVisible();
  if (preset) await page.getByText("Preset").locator("..").locator("select").selectOption(preset);
  await page.getByRole("button", { name: /Add to queue/i }).click();
  await page.getByRole("button", { name: "Export Queue" }).click();
}

test.beforeAll(() => {
  execFileSync(process.execPath, [join(root, "scripts", "generate-test-fixtures.mjs")]);
});

test.beforeEach(async ({ page }) => {
  await page.goto("./");
  await expect(page.getByText("VideoFlow", { exact: true }).first()).toBeVisible();
});

test("records actual browser AI capability", async ({ page, browserName }) => {
  const report = await page.evaluate(async () => {
    const gpu = (navigator as Navigator & { gpu?: { requestAdapter(): Promise<{ requestDevice(): Promise<unknown> } | null> } }).gpu;
    if (!gpu) return { webgpu: "unavailable", wasm: typeof WebAssembly !== "undefined" };
    try {
      const adapter = await gpu.requestAdapter();
      if (!adapter) return { webgpu: "unavailable", wasm: true };
      await adapter.requestDevice();
      return { webgpu: "available", wasm: true };
    } catch (error) {
      return { webgpu: "initialization-failed", wasm: true, detail: error instanceof Error ? error.message : String(error) };
    }
  });
  recordBrowserEvidence({ browserName, stage: "capability", ...report });
  expect(report.wasm).toBe(true);
});

test("loads from a nested base without root-relative asset failures", async ({ page }) => {
  const failed: string[] = [];
  page.on("requestfailed", (request) => failed.push(request.url()));
  await expect(page).toHaveURL(/\/VideoFlow\/$/);
  await expect(page.getByText("Deterministic FFmpeg render plan")).toBeVisible();
  await page.waitForTimeout(500);
  expect(failed).toEqual([]);
});

test("imports media, creates repeated clips, and operates every track control", async ({ page }) => {
  await importMedia(page, fixture);
  await page.getByText("overlap-source.mp4", { exact: true }).dblclick();
  await expect(page.locator(".vf-clip-video")).toHaveCount(2);

  await page.getByLabel("Mute V2").click();
  await expect(page.getByLabel("Unmute V2")).toBeVisible();
  await page.getByLabel("Solo V2").click();
  await expect(page.getByLabel("Unsolo V2")).toBeVisible();
  await page.getByLabel("Hide V2").click();
  await expect(page.getByLabel("Show V2")).toBeVisible();
  await page.getByLabel("V2 gain").fill("0.5");
  await expect(page.getByLabel("V2 gain")).toHaveValue("0.5");
  await page.getByLabel("Lock V2").click();
  await expect(page.getByLabel("Unlock V2")).toBeVisible();
});

test("quick tools are a genuine simplified workflow with Open in Editor", async ({ page }) => {
  await importMedia(page, fixture);
  await page.getByRole("button", { name: "Home" }).click();
  await page.getByRole("button", { name: /Text & subtitles/ }).click();
  await expect(page.getByRole("dialog")).toContainText("Simplified local workflow");
  await page.getByRole("dialog").locator("textarea").fill("Quick workflow title");
  await page.getByRole("button", { name: /Open in Editor/ }).click();
  await expect(page.locator(".vf-clip-text")).toHaveCount(1);
  await expect(page.getByText("Quick workflow title")).toBeVisible();
});

test("quick workflows expose merge, crop, speed, audio, logo and stream operations", async ({ page }) => {
  await importMedia(page, [fixture, tone, image]);
  await page.getByRole("button", { name: "Home" }).click();
  for (const name of [
    /Merge clips/,
    /Crop & resize/,
    /^Speed/,
    /Volume & audio/,
    /Add audio/,
    /Add image/,
    /Remove logo/,
    /^Compress/,
    /Extract audio/,
    /Remove audio/,
  ]) {
    await page.getByRole("button", { name }).click();
    await expect(page.getByRole("dialog")).toBeVisible();
    await expect(page.getByRole("button", { name: /Export/ }).last()).toBeVisible();
    await page.keyboard.press("Escape");
  }
});

test("undo/redo and save/reload preserve project state", async ({ page }) => {
  await importMedia(page, fixture);
  const clip = page.locator(".vf-clip-video").first();
  await clip.click();
  await page.getByRole("button", { name: /Add region/i }).click();
  await expect(page.getByLabel("Region 1 method")).toBeVisible();
  await page.getByRole("button", { name: /Undo/ }).click();
  await expect(page.getByLabel("Region 1 method")).toHaveCount(0);
  await page.getByRole("button", { name: /Redo/ }).click();
  await expect(page.getByLabel("Region 1 method")).toBeVisible();
  await expect(page.getByText(/Saved locally/)).toBeVisible({ timeout: 10_000 });
  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByRole("button", { name: "Projects" }).click();
  await page.locator(".vf-project-grid article button").first().click();
  await expect(page.locator(".vf-clip-video")).toHaveCount(1);
  await expect(page.getByLabel("Region 1 method")).toBeVisible();
});

test("project snapshots can be created and restored", async ({ page }) => {
  await importMedia(page, fixture);
  await page.getByRole("button", { name: "Project", exact: true }).click();
  await page.getByRole("menuitem", { name: "Create snapshot" }).click();
  await expect(page.getByText(/snapshot created/i)).toBeVisible();
  await page.getByRole("button", { name: "Projects" }).click();
  await expect(page.locator(".vf-snapshot-item")).toHaveCount(1);
  await page.locator(".vf-snapshot-item > button").first().click();
  await expect(page.locator(".vf-clip-video")).toHaveCount(1);
});

test("crop, resize, rotate and watermark direct manipulation remain editable", async ({ page }) => {
  await importMedia(page, fixture);
  const clip = page.locator(".vf-clip-video").first();
  await clip.click();
  await expect(page.getByRole("button", { name: "Crop", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Crop", exact: true }).click();
  const canvas = page.getByLabel("Video preview");
  const box = await canvas.boundingBox();
  expect(box).not.toBeNull();
  if (box) {
    await page.mouse.move(box.x + box.width * 0.25, box.y + box.height * 0.25);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.32, box.y + box.height * 0.30);
    await page.mouse.up();
  }
  await expect(page.getByRole("button", { name: "21:9" })).toBeVisible();
  await page.getByRole("button", { name: "Rotate", exact: true }).click();
  if (box) {
    await page.mouse.move(box.x + box.width * 0.75, box.y + box.height * 0.25);
    await page.mouse.down();
    await page.mouse.up();
  }
  await page.getByRole("button", { name: /Add region/i }).click();
  await page.getByLabel("Region 1 method").selectOption("pixelate");
  await page.getByRole("button", { name: /Add keyframe at/i }).click();
  await expect(page.getByText(/linear keyframe/)).toBeVisible();
});

test("command palette and core editor are keyboard reachable", async ({ page }) => {
  await page.keyboard.press(process.platform === "darwin" ? "Meta+K" : "Control+K");
  await expect(page.getByPlaceholder(/search/i)).toBeVisible();
  await page.keyboard.press("Escape");
  await importMedia(page, fixture);
  await page.locator(".vf-clip-video").first().click();
  await page.keyboard.press("ArrowRight");
  await page.keyboard.press("s");
  await expect(page.locator(".vf-clip-video")).toHaveCount(2);
  await page.keyboard.press(process.platform === "darwin" ? "Meta+z" : "Control+z");
  await expect(page.locator(".vf-clip-video")).toHaveCount(1);
});

test("reopens the installed shell while offline", async ({ page, context }) => {
  await page.evaluate(async () => { await navigator.serviceWorker?.ready; });
  await context.setOffline(true);
  await page.reload({ waitUntil: "domcontentloaded" });
  await expect(page.getByText("VideoFlow", { exact: true }).first()).toBeVisible();
  await context.setOffline(false);
});

test("responsive layouts retain an accessible scroll owner", async ({ page }) => {
  for (const viewport of [
    { width: 1440, height: 900 },
    { width: 768, height: 1024 },
    { width: 390, height: 844 },
  ]) {
    await page.setViewportSize(viewport);
    await page.reload({ waitUntil: "domcontentloaded" });
    await expect(page.getByText("VideoFlow", { exact: true }).first()).toBeVisible();
    const metrics = await page.evaluate(() => ({
      documentWidth: document.documentElement.scrollWidth,
      viewportWidth: window.innerWidth,
      bodyHeight: document.body.scrollHeight,
      viewportHeight: window.innerHeight,
    }));
    expect(metrics.documentWidth).toBeLessThanOrEqual(metrics.viewportWidth + 2);
    expect(metrics.bodyHeight).toBeGreaterThanOrEqual(metrics.viewportHeight);
  }
});

test("queues and completes validated deterministic MP4 output", async ({ page, browserName }) => {
  test.skip(browserName !== "chromium", "Full WASM encode is the Chromium release smoke; UI coverage runs in all engines.");
  await importMedia(page, fixture);
  await queueMp4(page, "balanced");
  await expect(page.getByText("Complete", { exact: true })).toBeVisible({ timeout: 180_000 });
  await expect(page.getByText(/H\.264|h264/i)).toBeVisible();
});

test("small real 4K fixture imports, edits and exports at 3840x2160", async ({ page, browserName }) => {
  test.skip(browserName !== "chromium", "The real 4K WASM encode is the Chromium certification gate.");
  const uhd = join(generated, "uhd-4k-5s.mp4");
  await importMedia(page, uhd);
  await expect(page.getByText(/3840×2160/).first()).toBeVisible();
  await page.locator(".vf-clip-video").first().click();
  await page.getByRole("button", { name: /Add region/i }).click();
  await page.getByLabel("Region 1 method").selectOption("blur");
  await page.getByRole("button", { name: /Add text/i }).click();
  await queueMp4(page, "youtube-4k");
  await expect(page.getByText("Complete", { exact: true })).toBeVisible({ timeout: 360_000 });
  await expect(page.getByText(/3840×2160/)).toBeVisible();
});

test("bundled AI executes a genuine local neural preview with tracking and offline reuse", async ({ page, context }) => {
  test.setTimeout(300_000);
  const aiFixture = join(root, "tests", "fixtures", "ai", "ai-static-watermark-720p.mp4");
  await importMedia(page, aiFixture);
  await page.locator(".vf-clip-video").first().click();
  await page.getByRole("button", { name: /Add region/i }).click();
  await expect(page.getByText("AI Reconstruction", { exact: true }).last()).toBeVisible();
  const bundled = page.getByRole("button", { name: /Install bundled AI/i });
  await expect(bundled).toBeVisible({ timeout: 30_000 });
  await bundled.click();
  await expect(page.getByText(/checksum verified/i)).toBeVisible({ timeout: 120_000 });
  await page.getByLabel("Region 1 method").selectOption("ai");
  await page.getByRole("button", { name: /Preview current frame/i }).click();
  await expect(page.locator(".vf-ai-preview")).toBeVisible({ timeout: 180_000 });
  const inferenceEvidence = await page.getByText(/inference.*ROI/i).textContent();
  expect(inferenceEvidence).toBeTruthy();
  recordBrowserEvidence({ browserName, stage: "ai-inference", detail: inferenceEvidence });
  await page.getByRole("button", { name: /Track Forward/i }).click();
  await expect(page.getByText(/average confidence/i)).toBeVisible({ timeout: 60_000 });
  await expect(page.getByText(/Saved locally/)).toBeVisible({ timeout: 15_000 });

  await page.evaluate(async () => { await navigator.serviceWorker?.ready; });
  await context.setOffline(true);
  await page.reload({ waitUntil: "domcontentloaded" });
  await expect(page.getByText("VideoFlow", { exact: true }).first()).toBeVisible();
  await page.getByRole("button", { name: "Projects" }).click();
  await page.locator(".vf-project-grid article button").first().click();
  await page.locator(".vf-clip-video").first().click();
  await expect(page.getByText(/LaMa 512 INT8/)).toBeVisible();
  await page.getByRole("button", { name: /Preview current frame/i }).click();
  await expect(page.locator(".vf-ai-preview")).toBeVisible({ timeout: 180_000 });
  await context.setOffline(false);
});

test("Chromium produces a real 3840x2160 AI-assisted output", async ({ page, browserName }) => {
  test.skip(browserName !== "chromium", "The 4K AI encode is the Chromium hard certification gate; Firefox/WebKit run the local AI preview test.");
  test.setTimeout(420_000);
  const ai4k = join(root, "tests", "fixtures", "ai", "ai-watermark-4k-short.mp4");
  await importMedia(page, ai4k);
  await page.locator(".vf-clip-video").first().click();
  await page.getByRole("button", { name: /Add region/i }).click();
  await expect(page.getByRole("button", { name: /Install bundled AI/i })).toBeVisible({ timeout: 30_000 });
  await page.getByRole("button", { name: /Install bundled AI/i }).click();
  await expect(page.getByText(/checksum verified/i)).toBeVisible({ timeout: 120_000 });
  await page.getByLabel("Region 1 method").selectOption("ai");
  await page.getByRole("button", { name: /Preview current frame/i }).click();
  await expect(page.locator(".vf-ai-preview")).toBeVisible({ timeout: 180_000 });
  await expect(page.getByText(/ROI/i).last()).toBeVisible();
  await queueMp4(page, "youtube-4k");
  await expect(page.getByText("Complete", { exact: true })).toBeVisible({ timeout: 360_000 });
  await expect(page.getByText(/3840×2160/)).toBeVisible();
});
