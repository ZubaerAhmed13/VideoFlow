import { expect, test } from "@playwright/test";
import { execFileSync } from "node:child_process";
import { join } from "node:path";

const root = process.cwd();
const large = join(root, "outputs", "certification", "large-3gb-4k-sparse.mp4");

test.beforeAll(() => {
  if (process.env.VIDEOFLOW_LARGE_MEDIA_CERT === "1")
    execFileSync(process.execPath, [join(root, "scripts", "generate-certification-media.mjs")]);
});

test("3 GiB 4K source uses session/reference architecture, proxy persistence and relink", async ({ page, browserName }) => {
  test.skip(browserName !== "chromium" || process.env.VIDEOFLOW_LARGE_MEDIA_CERT !== "1", "Dedicated Chromium large-media certification only.");
  test.setTimeout(600_000);
  await page.goto("./");
  await page.getByTestId("media-import").setInputFiles(large);
  await expect(page.getByRole("dialog", { name: /Large Media Detected/i })).toBeVisible({ timeout: 30_000 });
  await expect(page.getByText(/3(\.0)? GB|3 GiB/i)).toBeVisible();
  await page.getByRole("button", { name: "Session Only" }).click();
  await expect(page.getByText(/session-attached/i)).toBeVisible();

  await page.getByRole("button", { name: "Video Tools" }).click();
  await expect(page.getByText(/large-3gb-4k-sparse\.mp4/)).toBeVisible();
  await page.getByRole("button", { name: /Generate proxy/i }).click();
  await expect(page.getByText(/Proxy ready|Editing proxy ready/i)).toBeVisible({ timeout: 300_000 });
  await expect(page.getByText(/Saved locally/)).toBeVisible({ timeout: 15_000 });

  await page.reload({ waitUntil: "domcontentloaded" });
  await page.getByRole("button", { name: "Projects" }).click();
  await page.locator(".vf-project-grid article button").first().click();
  await page.getByRole("button", { name: "Video Tools" }).click();
  await expect(page.getByText(/Proxy ready/)).toBeVisible();

  await page.getByTestId("media-relink").setInputFiles(large);
  await expect(page.getByText(/original source.*relinked/i)).toBeVisible();

  await page.getByRole("button", { name: "Video Editor" }).click();
  await page.getByRole("button", { name: "Export", exact: true }).last().click();
  await page.getByText("Export from (seconds)").locator("..").locator("input").fill("0");
  await page.getByText("Export to (seconds)").locator("..").locator("input").fill("1");
  await page.getByText("Preset").locator("..").locator("select").selectOption("youtube-4k");
  await page.getByRole("button", { name: /Add to queue/i }).click();
  await page.getByRole("button", { name: "Export Queue" }).click();
  await expect(page.getByText("Complete", { exact: true })).toBeVisible({ timeout: 300_000 });
  await expect(page.getByText(/3840×2160/)).toBeVisible();
});
