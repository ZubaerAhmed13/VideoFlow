import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

test("renders VideoFlow metadata and local-first shell", async () => {
  const html = await readFile(new URL("../dist/index.html", import.meta.url), "utf8");
  assert.match(html, /<title>VideoFlow Professional Core<\/title>/i);
  assert.match(html, /<link rel="manifest" href="\.\/manifest\.webmanifest"/i);
  assert.match(html, /Local Mode/i);
  assert.match(html, /Video Editor/i);
  assert.doesNotMatch(html, /codex-preview/i);
});
