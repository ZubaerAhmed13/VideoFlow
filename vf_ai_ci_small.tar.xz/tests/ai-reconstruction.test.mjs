import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL(`../${path}`, import.meta.url), "utf8");

test("AI registry uses a real checksum-validated Apache-2.0 LaMa model descriptor", async () => {
  const source = await read("lib/videoflow/ai/AIModelRegistry.ts");
  assert.match(source, /LaMa 512 INT8/);
  assert.match(source, /Apache-2\.0/);
  assert.match(source, /cab19978adc306622fe37ef60d4a52103b99c98141d499c2a2366a7ed1255dbe/);
  assert.match(source, /inputWidth:\s*512/);
});

test("AI model install verifies SHA-256 and persists model in a protected local cache", async () => {
  const source = await read("lib/videoflow/ai/AIModelLoader.ts");
  assert.match(source, /crypto\.subtle\.digest\("SHA-256"/);
  assert.match(source, /AI Model Validation Failed/);
  assert.match(source, /videoflow-ai-models-v1/);
  assert.match(source, /cache\.put/);
});

test("AI inference is genuine ONNX execution with worker isolation and WebGPU to WASM fallback", async () => {
  const engine = await read("lib/videoflow/ai/AIInferenceEngine.ts");
  const worker = await read("workers/ai-inference.worker.ts");
  assert.match(engine, /runWorkerInpainting/);
  assert.match(worker, /InferenceSession\.create/);
  assert.match(worker, /session\.run/);
  assert.match(worker, /\["webgpu",\s*"wasm"\]|providers/);
  assert.match(worker, /\["wasm"\]/);
  assert.doesNotMatch(worker, /blur|pixelate|clone/i);
});

test("4K AI path performs fixed-size ROI inference rather than full-frame neural inference", async () => {
  const manager = await read("lib/videoflow/ai/AIManager.ts");
  const roi = await read("lib/videoflow/ai/inpainting/ROIPreprocessor.ts");
  assert.match(manager, /extractROI\(source, roi, 512\)/);
  assert.match(roi, /normalizedMaskToROI/);
  assert.match(roi, /Math\.min/);
});

test("AI quality modes materially alter ROI and temporal processing", async () => {
  const source = await read("lib/videoflow/ai/AIManager.ts");
  assert.match(source, /fast:/);
  assert.match(source, /high:/);
  assert.match(source, /maximum:/);
  assert.match(source, /temporalWindow:\s*3/);
  assert.match(source, /Math\.max\(settings\.temporalWindow, 15\)/);
  assert.match(source, /consistencyStrength/);
});

test("AI export is bounded, cancellable and preserves original audio", async () => {
  const source = await read("lib/videoflow/ai/VideoInpainter.ts");
  assert.match(source, /duration > 8\.05/);
  assert.match(source, /signal\.aborted/);
  assert.match(source, /reconstructFrame\([\s\S]*signal\)/);
  assert.match(source, /AI source audio/);
  assert.match(source, /kind = "audio"/);
});

test("AI masks cannot fall through to a fake FFmpeg blur implementation", async () => {
  const plan = await read("lib/videoflow/render-plan.mjs");
  assert.match(plan, /AI masks must be neural-preprocessed/);
  const app = await read("components/videoflow/VideoFlowApp.tsx");
  assert.match(app, /never relabels blur, pixelate, cover or clone as AI/);
});

test("PWA protects separately installed AI caches and does not auto-precache ONNX models", async () => {
  const sw = await read("public/service-worker.js");
  assert.match(sw, /videoflow-ai-/);
  assert.match(sw, /\/models\/.*\\\.onnx|models/);
  assert.match(sw, /precache-manifest\.json/);
});

test("large-media fingerprints use sampled SHA-256 identity checks", async () => {
  const source = await read("lib/videoflow/media.ts");
  assert.match(source, /PARTIAL_HASH_SAMPLE_BYTES\s*=\s*4 \* 1024 \* 1024/);
  assert.match(source, /SHA-256/);
  assert.match(source, /Math\.floor\(\(file\.size - sampleSize\) \/ 2\)/);
  assert.match(source, /fingerprintMatchesAsync/);
});

test("temporal stabilization uses real block-motion estimation before blending", async () => {
  const estimator = await read("lib/videoflow/ai/temporal/MotionEstimator.ts");
  const temporal = await read("lib/videoflow/ai/temporal/TemporalContext.ts");
  assert.match(estimator, /coarse-to-fine luminance block matching/);
  assert.match(estimator, /translationError/);
  assert.match(estimator, /translateImage/);
  assert.match(estimator, /does not claim a dense per-pixel flow field/);
  assert.match(temporal, /estimateTranslation/);
  assert.match(temporal, /confidence/);
  assert.match(temporal, /translateImage/);
});

test("AI settings expose real local self-test, storage removal and manual tracking correction persistence", async () => {
  const settings = await read("components/videoflow/AISettingsPanel.tsx");
  const app = await read("components/videoflow/VideoFlowApp.tsx");
  assert.match(settings, /Run AI self-test/);
  assert.match(settings, /runImageInpainting/);
  assert.match(settings, /Remove AI model/);
  assert.match(settings, /saveAIDefaultSettings/);
  assert.match(app, /manual correction anchor/);
  assert.match(app, /manual:\s*true/);
});

test("output policy is capability-aware instead of using a universal 1.5 GiB cutoff", async () => {
  const policy = await read("lib/videoflow/import-policy.mjs");
  const exporter = await read("lib/videoflow/export.ts");
  assert.match(policy, /deviceMemoryGb/);
  assert.match(policy, /inMemoryLimitBytes/);
  assert.match(policy, /inMemoryAllowed/);
  assert.match(policy, /500 \* MEBIBYTE/);
  assert.doesNotMatch(exporter, /1\.5 \* GIBIBYTE/);
  assert.match(exporter, /!risk\.inMemoryAllowed/);
});
