# VideoFlow Professional Core 1.0.0 — Browser Support

Status date: 2026-08-30

“Implemented” describes source/static capability. `NOT VERIFIED` means the actual browser gate did not execute and is never converted into PASS.

| Capability | Chromium | Firefox | WebKit/Safari |
| --- | --- | --- | --- |
| Core editing | Implemented / NOT VERIFIED runtime | Implemented / NOT VERIFIED | Implemented / NOT VERIFIED |
| FFmpeg | Implemented / NOT VERIFIED runtime | Implemented / NOT VERIFIED | Implemented / NOT VERIFIED |
| 4K browser export | NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |
| 3 GB reference architecture | Implemented; structural PASS | Session/relink fallback implemented | Session/relink fallback implemented |
| Persistent file handles | Supported when File System Access API exists | Fallback relink/session | Fallback relink/session |
| Direct-to-disk output | Implemented when `showSaveFilePicker`/`createWritable` exist | Standard-download fallback | Platform-dependent fallback |
| AI WebGPU | Implemented; NOT VERIFIED | Provider-dependent; NOT VERIFIED | Provider-dependent; NOT VERIFIED |
| AI WASM | Implemented; NOT VERIFIED | Implemented; NOT VERIFIED | Implemented; NOT VERIFIED |
| AI tracking | Implemented; NOT VERIFIED runtime | Implemented; NOT VERIFIED | Implemented; NOT VERIFIED |
| Offline AI | Architecture implemented; NOT VERIFIED | NOT VERIFIED | NOT VERIFIED |
| PWA | Static PASS / runtime NOT VERIFIED | Static PASS / runtime NOT VERIFIED | Platform-dependent / NOT VERIFIED |

## Environment boundary

The available Chromium is controlled by enterprise `URLBlocklist: ["*"]`; localhost, `file:` and `data:` navigation returns `net::ERR_BLOCKED_BY_ADMINISTRATOR`. Playwright Firefox/WebKit browser binaries are not installed, and browser/package downloads are unavailable from this runtime. A fresh `npm ci` also cannot complete because package-registry network/DNS access is unavailable.

## Automated release workflow

The included GitHub Actions release workflow is designed to restore locked dependencies, stage the checksum-pinned AI pack, build a fresh production `dist/`, install Chromium/Firefox/WebKit and run the browser, PWA/offline, 4K, AI and packaging gates in an unrestricted runner.
